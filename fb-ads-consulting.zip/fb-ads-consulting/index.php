<?php
error_reporting(1);
require("./include/gobal.php");
require("./include/class.db.php");
$db = new db("mysql:host=".SYS_DBHOST.";dbname=".SYS_DBNAME, SYS_DBUSER, SYS_DBPW);
$email = htmlspecialchars($_GET['email']);
$sql = "select * from user where email_name = '{$email}' order by date desc limit 1";
$user=$db->run($sql);
if(empty($user)){
	header('location:http://www.rutubo-consulting.jp');
	exit;
}
$year=substr($user[0]['date'], 0, 4);
$month=substr($user[0]['date'], 5, 2)-1;
$day=substr($user[0]['date'], 8, 2);
?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<meta name="robots" content="noindex,nofollow">
<title>Rutubo Consulting | Facebook広告4週間集中コンサルティング</title>
<meta name="description" content="Rutubo Consulting | Facebook広告4週間集中コンサルティング" />
<meta name="keywords" content="FB広告,ネット集客" />
<meta name="viewport" content="width=device-width,initial-scale=1.0" />
<link rel="stylesheet" type="text/css" href="css/top.css">
<link rel="stylesheet" type="text/css" href="css/form_button.css">
<link rel="stylesheet" type="text/css" href="css/form_button2.css">
<link rel="stylesheet" type="text/css" href="css/countdown.css">
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script type="text/javascript" src="js/pagetop.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<link rel="stylesheet" href="countdown/css/soon.min.css" type="text/css">
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
<link rel="icon" href="images/favicon.ico" type="image/x-icon">
<!--<script type="text/javascript" src="js/top.js"></script>-->
<!--[if lt IE 9]>
<script src="js/html5shiv.min.js"></script>
<script src="http://css3-mediaqueries-js.googlecode.com/"></script>
<![endif]-->

<!-- FORM -->

<script>
function CountdownTimer( elemID, timeLimit, limitMessage, msgClass ) {
    this.initialize.apply( this, arguments );
}
 
CountdownTimer.prototype =     {
 
    /**
     * Constructor
     */
    initialize: function( elemID, timeLimit, limitMessage, msgClass ) {
        this.elem = document.getElementById( elemID );
        this.timeLimit = timeLimit;
        this.limitMessage = limitMessage;
        this.msgClass = msgClass;
    },
 
    /**
     * カウントダウン
     */
    countDown : function()    {
        var    timer;
        var    today = new Date()
        var    days = Math.floor( ( this.timeLimit - today ) / ( 24 * 60 * 60 * 1000 ) );
        var    hours = Math.floor( ( ( this.timeLimit - today ) % ( 24 * 60 * 60 * 1000 ) ) / ( 60 * 60 * 1000 ) );
        var    mins = Math.floor( ( ( this.timeLimit - today ) % ( 24 * 60 * 60 * 1000 ) ) / ( 60 * 1000 ) ) % 60;
        var    secs = Math.floor( ( ( this.timeLimit - today ) % ( 24 * 60 * 60 * 1000 ) ) / 1000 ) % 60 % 60;
        var    milis = Math.floor( ( ( this.timeLimit - today ) % ( 24 * 60 * 60 * 1000 ) ) / 10 ) % 100;
        var    me = this;
 
            if( ( this.timeLimit - today ) > 0 ){
            timer = '先着10名様限定。受付終了まであと' + days + '日と' + this.addZero( hours ) + '時間' + this.addZero( mins ) + '分'+ this.addZero( secs ) + '秒'  + this.addZero( milis ) ;
            this.elem.innerHTML = timer;
            tid = setTimeout( function() { me.countDown(); }, 10 );
 
            }else{
            this.elem.innerHTML = this.limitMessage;
            if( this.msgClass )    {
                this.elem.setAttribute( 'class', this.msgClass );
            }
            return;
            }
    },
 
    /**
     * ゼロを付与
     */
    addZero : function( num )    {
        num = '00' + num;
        str = num.substring( num.length - 2, num.length );
 
        return str ;
    }
}
 
// end of JavaScript -->
</script>

</head>

<body>

<?php include_once("analyticstracking.php") ?>

<div class="timer_1" id="sampleA"></div>
<script language="JavaScript" type="text/javascript">

cdTimer1();
 
function cdTimer1()    {
 
// 設定項目 ここから---------------------------------------------
    // タグ要素のID名
    var    elemID = 'sampleA';
 
    // 期限日数を設定
    var    limit    =    4;  

    // 期限日を設定
    var    ymd      =    new Date(<?php echo $year;?>,<?php echo $month;?>,<?php echo $day;?>);

    //alert(ymd);
    
    ymd.setDate(ymd.getDate()+limit);

	//alert(ymd);

    var    year    =    ymd.getFullYear();               // 年
    var    month    =    ymd.getMonth()+1;               // 月
    var    day        =    ymd.getDate();               // 日
 
    // 期限終了後のメッセージ
    var    limitMessage    =    '満員御礼！募集は終了しました！';
 
    // メッセージのスタイルクラス名（変更しない場合は空欄）
    var    msgClass = 'msg_1';
// 設定項目 ここまで---------------------------------------------
 
    var    timeLimit = new Date( year, month - 1, day );
    var    timer = new CountdownTimer( elemID, timeLimit, limitMessage, msgClass );
    timer.countDown();
}
 

</script>
 
</div>

<header id="pagetop">

	<header id="header" role="banner">
	  <div class="header">
	    <p class="header_title"><img src="images/header_title.png" alt=""></p>
	    <p class="header_company"><img src="images/header_company.png" alt=""></p>
	  </div>
	</header>

	</div>
</div>

	<!-- MAIN VISUAL -->
	<div id="mainv">
		<p id="mainfront"><img src="images/main_front.png" /></p>
		<p id="lead"><img src="images/lead.png" alt=""/></p>
	</div>
	<!-- MAIN VISUAL -->

</header>
<div id="container">
	<div id="content">

	<section>

		<!--
		<p class="catch_timer center"><img src="images/catch1.png" alt="5日間限定先着10名様限定"/>
		<script src="countdown/js/soon.min.js"></script>
		<div class="soon" id="my-soon-counter"
		     data-due="2016-10-06T23:59:59"
		     data-event-complete="soonCompleteCallback"
		     data-layout="group"
		     data-format="d,h,m,s"
		     data-face="slot roll left fast"
		     data-visual="ring cap-round invert progressgradient-fb801b_f1d935 ring-width-custom">
		</div>-->

		<div class="lead_content_box clearfix">
			<div class="SectionTxt">
		<p class="mg-b2">こんにちは。合同会社Rutubo代表の小池英樹です。<br />
<span class="yellow"><strong>さっそくですが、今日はあなたに「緊急のお知らせ」があります。</strong></span></p>
		<p class="mg-b2">実は、つい先日とてもうれしいメールをいただいたのです。<br />
<strong>そのメールは「小予算で大量集客出来るようになる！<br />Facebook広告徹底ガイド動画講座（以下Facebook広告徹底ガイド動画講座）」の<br />
ご購入者様からいただいたものでした。</strong></p>
		<p class="mg-b1">今日はそのメールをご紹介したくて、こうしてあなたにご案内を差し上げています。<br />
以下、さっそくご紹介します。</p>
			</div>
		</div>

		<p class="catch center mg-b2"><img src="images/intro_voice.png" alt=""/></p>

		<div class="content_box clearfix">
			<div class="SectionTxt">
		<p class="mg-b2">ご丁寧にメールをくださったY.Tさま！<br />
誠にありがとうございます。この場を借りてお礼を申し上げます。</p>
		<p class="mg-b2">「Facebook広告徹底ガイド動画講座」のご購入者様の中には、<br />
Y.T様のメールで「勇気」と「やる気」をもらった方々も大勢いると思います。</p>
		<p class="mg-b2">私にしても、Facebook広告徹底ガイド動画講座を提供するうえで<br />
Y.T様からのような成功事例の報告が何よりも励みになります。<br />
本当に有難いし、うれしく思います。</p>
		<p class="mg-b2">さて、ここであなたに「緊急のお知らせ」があります。</p>
		<p class="mg-b2"><strong>私はY.T様のような成功事例をもっともっと聞きたいし、<br />
私の持っているFacebook広告のノウハウがそのためのきっかけに少しでも役立つのであれば、<br />
できる限りのことをしたいと考えています。</strong></p>
		<p class="mg-b2"><span class="yellow"><strong>そこで、今回は「Facebook広告徹底ガイド4週間コンサルティング」として、<br />
個別にFacebook広告のノウハウを伝授いたします。</strong></span></p>
			</div>
		</div>

		<div class="feature_box">
			<p class="catch center mg-t1  mg-b1"><img src="images/point_catch.png" alt=""/></p>
			<div class="feature_detail SectionTxt clearfix">
				<p class="feature_img"><img src="images/point_img.png" alt=""/></p>
					<p class="mg-b2">Facebook広告徹底ガイド動画講座の受講生の方も、<br />
書籍やセミナーで学習なさっている方も、<br />
カリキュラムをこなしてスキルは身につきますが、<br />
それは、まだ「点」の状態。<br />
「点」の状態のまま、グルグル回ってしまって、その先になかなかステップアップできていないケースが多いのです。</p>
					<p class="mg-b2">インプット（＝学習）ばかりで、アウトプット（＝Facebook広告運営）をどのようにやっていけばいいかわからない。<br />
<span class="yellow"><strong>そんなふうにお悩みの方が多いのですが、実は、ステップアップには、<br />
アカウント構築・広告運営・広告改善の一連の流れを実践を通して覚えるのが一番の近道です。</strong></span></p>
					<p class="mg-b2"><strong>「点」と「点」がつながれば、急に自信がつき、自信を持って広告運営をできる時がやってきます。<br />
それは、小予算で大量集客する力になります。</strong></p>
					<p class="mg-b2">独学でFacebook広告を学習されている方はどこでつまづいているか？<br />
					どうしたら、費用対効果の高い広告運営に必要な知識、技術を効率よく身につけることができるのか？</p>
					<p class="mg-b2">私自身やFacebook広告に投資している私のクライアント50社以上の歳月と<br />
						1億5千万円以上の広告費と投資して実際に得られた効果実証済みのFacebook広告運営のノウハウを基に、<br />
						考え抜いて作ったのが、「Facebook広告徹底ガイド動画講座」でした。</p>
					<p class="mg-b2">実際、冒頭の受講生の方からのお声であったように、Facebook広告の教材としては、<br />
						自信を持って最高峰の情報をご提供出来ていると思います。</p>
					<p class="mg-b2"><span class="yellow"><strong>しかし、お声で頂戴したように、ビジネスが千差万別であるならば、<br />
						個々のビジネスに合わせて広告運営のノウハウが必要なのも事実です。</strong></span></p>
					<p class="mg-b2"><strong>そこで、独学でFacebook広告を学習されていて知りたかったこと、<br />
						悩んでいることを解決することであなたのお役に立ちたい。</strong></p>
					<p class="mg-b2"><span class="yellow"><strong>そのような想いで、今回、個別にFacebook広告のノウハウを伝授するために、<br />
						「Facebook広告徹底ガイド4週間コンサルティング」を始めることにいたしました。</strong></span></p>
					<p class="mg-b2">コンサルティングでは、あなたに「ここが知りたかったんです！」と<br />
						言って頂けるように私の全てをかけて臨みます。</p>
					<p class="mg-b1">わからないところ、つまずいている部分は、解決するまで徹底的にサポートいたします。</p>
			</div>
		</div>

		<p class="catch center"><img src="images/profile_1.png" alt="小池英樹のプロフィール"/></p>

		<div class="content_box clearfix">
			<div class="SectionTxt">
		<p class="mg-b2">こちらのコンサルティングでは、<br />
			<span class="yellow"><strong>実際にあなたが運営しているFacebook広告のアカウントを、<br />
			私が拝見して、広告の運営を最適化するお手伝いをいたします。<br />
必要であれば、ゼロベースでアカウントを構築し直し、<br />
あなた自身のFacebook広告アカウントで、<br />
小予算で大量集客出来るようにサポートさせて頂きます。</strong></span></p>

		<p class="mg-b2">正直、このサービスは相当な手間と時間がかかります。<br />
Facebook広告運営のコンサルティングは広告運営だけでなくて、<br />
販売プランの設計アドバイスや営業コンサルティングも含んだサービスになるからです。</p>

<p class="mg-b2">まずは、<br />
<br />
・販売プランの中でFacebook広告をどう使うのか？<br />
・ターゲットは誰なのか？<br />
・何をオファーするのか？</p>

		<p class="mg-b2">こんなヒアリングから始めて、<br />
実際、運営されているFacebook広告のアカウントを見直していきます。<br />
<strong>私の経験上、現在のオファーでは反応が期待できない場合は、<br />
「こういうオファーはどうか？」という提案もさせていただきますし、<br />
可能であればオファーを変更してもらうこともあります。</strong></p>

		<p class="">それから勿論…</p>

			</div>
		</div>		

		<p class="catch center"><img src="images/knowhow_catch.png" alt=""/></p>

		<div class="results_box">

			<div class="content_box clearfix">
				<div class="SectionTxt">
					<p class="mg-t1">あなた自身のビジネスでFacebook広告をどのように運営すれば良いのか、<br />
						すべて1から丁寧にお教えします。具体的には、以下のノウハウを伝授します。
				</div>	
			</div>	

			<div class="results_l clearfix">
				<div class="results_img feature_img2"><p class=""><img src="images/feature1.png" alt=""/></p></div>
				<div class="results_text feature_text mg-t1">
					<p class="results_text1">利益率の高いネット広告運営の収支設計の仕方</p>
					<p class="results_text2 SectionTxt mg-t1">Facebook広告を運営する上で、まず最初に大切なのが、利益率の高い収支設計をすることです。
どれだけ広告費を投資すればどれだけのリターンが得られるのか、リターンを最大にするためにはどのようなビジネスモデルを構築すれば良いのかを考えることが大切です。
<span class="yellow"><strong>コンサルティングでは、弊社オリジナルの収支設計表に必要項目を記入頂き、目標の売上や利益を設定して頂きます。</strong></span>
				</div>
			</div>
			<div class="results_r mg-t2 clearfix">
				<div class="results_img feature_img3"><p class=""><img src="images/feature2.png" alt=""/></p></div>
				<div class="results_text feature_text mg-t1">
					<p class="results_text1">成果の出やすいキャンペーン構築の仕方</p>
					<p class="results_text2 SectionTxt mg-t1">
					Facebook広告は「キャンペーン」、「広告セット」、「広告」という3つの階層から成り立っています。
					この階層構造を理解し、あなた自身のビジネスで最適なキャンペーン構造を構築することが、費用対効果の高い広告運営に必須になってきます。
					<span class="yellow"><strong>コンサルティングでは、広告予算やお取り扱いの商品・サービスやターゲットユーザーを総合的に俯瞰して、最も成果の出やすいキャンペーンを構築します。</strong></span>
					</p>
				</div>
			</div>
			<div class="results_l mg-t2 clearfix">
				<div class="results_img feature_img2"><p class=""><img src="images/feature3.png" alt=""/></p></div>
				<div class="results_text feature_text mg-t1">
					<p class="results_text1">狙いすましたターゲティング設定の仕方</p>
					<p class="results_text2 SectionTxt mg-t1">
					Facebook広告は、自社で保有している顧客データベースを元に広告を出すことが出来ます。
					特に、顧客リストが既に100件以上あれば、類似オーディエンスと呼ばれる強力なターゲティング機能を利用することが出来ます。
					<span class="yellow"><strong>コンサルティングでは、Facebook広告ならではのカスタムオーディエンス機能を使いこなして、あなたが望むターゲットユーザーに最適なタイミングで広告を配信する方法を伝授します。</strong></span>
					</p>
				</div>
			</div>
			<div class="results_r mg-t2 clearfix">
				<div class="results_img feature_img3"><p class=""><img src="images/feature4.png" alt=""/></p></div>
				<div class="results_text feature_text mg-t1">
					<p class="results_text1">成約率の高い広告クリエイティブの作り方</p>
					<p class="results_text2 SectionTxt mg-t1">Facebook広告は、広告クリエイティブの出来次第で、広告のパフォーマンスが大きく変わります。
Facebook広告は、他のネット広告とは違い、直接、Facebookユーザーからの反応が返ってきます。そして、ユーザーからの評価が広告のパフォーマンスに大きな影響を与えます。そのため、ユーザーから好感を持ってもらえるような広告クリエイティブを作ることが求められます。<span class="yellow"><strong>コンサルティングでは、あなた自身のサービスやブランドに合った魅力的な広告クリエイティブの作り方を指導します。</strong></span></p>
				</div>
			</div>
			<div class="results_l mg-t2 clearfix">
				<div class="results_img feature_img2"><p class=""><img src="images/feature5.png" alt=""/></p></div>
				<div class="results_text feature_text mg-t1">
					<p class="results_text1">繰り返すごとに費用対効果が増すABテストの仕方</p>
					<p class="results_text2 SectionTxt mg-t1">ABテストとは、2つ以上の異なるパターンを比較し、どちらが効果が高いかを見極めるテストのことを指します。
<span class="yellow"><strong>コンサルティングでは、最適なABテスト用の広告クリエイティブの作り方から、
あなた自身のFacebook広告アカウントでABテストに特化したキャンペーン構造の作り方までお教えします。</strong></span>
そして、実際にABテストを行った後に、各種指標からどのようにして広告運営を改善していくのかについてご説明します。
					</p>
				</div>
			</div>
			<div class="results_r mg-t2 clearfix">
				<div class="results_img feature_img3"><p class=""><img src="images/feature6.png" alt=""/></p></div>
				<div class="results_text feature_text mg-t1">
					<p class="results_text1">広告指標を読み解きパフォーマンスを高める方法</p>
					<p class="results_text2 SectionTxt mg-t1">Facebook広告では、広告運営の期間中、常に広告効果のデータのチェックが可能で、
そのデータに基づきながら広告運営の改善が可能です。
<span class="yellow"><strong>コンサルティングでは、あなた自身のFacebook広告アカウントで、
各種指標から実際にどのように広告運営を改善するのかについて、具体的なノウハウをご紹介します。</strong></span>
ノウハウ通りに広告を運営頂ければ、日に日に広告のパフォーマンスが高くなります。</p>
				</div>
			</div>

		</div>

		<div class="content_box clearfix">
			<div class="SectionTxt">
		<p class="mg-b2">他にも私なりに培ったノウハウを駆使して、<br />
Facebook広告を使って売上を上げるための具体的なアドバイスを行うわけですが、<br />
とにかく１つのネット集客の仕組みやFacebook広告のアカウントを見直して、<br />
最適化するのに相当な時間と労力が必要になります。</p>
		<p class="mg-b2"><span class="yellow"><strong>それゆえ、人数限定のサービスになりますが、<br />
私のアドバイスに価値があると思って頂けたなら、<br />
本サービスにいち早くお申し込みください。</strong></span></p>
		<p class="mg-b1">それでは、コンサルティングのカリキュラムをお伝えします。</p>
			</div>
		</div>

		<p class="catch center"><img src="images/fb_consulting.png" alt=""/></p>

		<div class="curriculum2_box mg-t3">
			<p class="curriculum2_title"><span class="curriculum2_box2">1週目.</span>Facebook広告アカウント構築</p>
			<div class="curriculum_detail clearfix">
				<div class="SectionTxt">
					<p class="">
1週目は、あなたの運営中のFacebook広告のアカウントを見直し、<br />
より成果の出やすいキャンペーン構造に改善します。<br />
また、ターゲティングや広告予算や収益目標を決定するとともに、<br />
広告クリエイティブを作成します。<br />
さらに、必要に応じて、販売プランの設計のアドバイスもいたします。
					</p>
				</div>
			<p class="catch"><img src="images/curriculum_image1.png" alt=""/></p>
			<ul class="curriculum2_list">
				<li>アカウントの見直しと再構築</li>
				<li>ターゲティング設定の決定</li>
				<li>広告予算の決定</li>
				<li>収益目標の決定</li>
				<li>オファーの見直しと変更</li>
				<li>広告クリエイティブの作成</li>
			</ul>
			</div>
			<p class="curriculum2_title mg-t1"><span class="curriculum2_box2">2週目.</span>Facebook広告運営1週目</p>
			<div class="curriculum_detail clearfix">
				<div class="SectionTxt">
					<p class="">
2週目では、1週目で構築したアカウントで実際に広告運営を開始します。<br />
広告運営時には、ABテストを行い、より成果の高い広告クリエイティブのパターンを探ります。<br />

					</p>
				</div>
			<p class="catch curriculum_img3"><img src="images/curriculum_image2.png" alt=""/></p>
			<ul class="curriculum2_list">
				<li>ABテストの実施（バナー広告クリエイティブ）</li>
				<li>広告素材の作成（動画広告クリエイティブ）</li>
			</ul>
			</div>
			<p class="curriculum2_title mg-t1"><span class="curriculum2_box2">3週目.</span>Facebook広告運営2週目</p>
			<div class="curriculum_detail clearfix">
				<div class="SectionTxt">
					<p class="">
3週目では、2週目で運営した広告の成果を分析します。<br />
分析した結果を受けて、ターゲティングや配置や広告予算の設定などを見直し改善します。<br />
また、広告運営の2週目は新たに動画の広告クリエイティブを加えて広告の運営を実施します。
					</p>
				</div>
			<p class="catch curriculum_img3"><img src="images/curriculum_image3.png" alt=""/></p>
			<ul class="curriculum2_list">
				<li>広告運営の分析</li>
				<li>ターゲティングや配置や広告予算の見直しと改善</li>
				<li>ABテストの実施（バナー広告クリエイティブ・動画広告クリエイティブ）</li>
			</ul>
			</div>
			<p class="curriculum2_title mg-t1"><span class="curriculum2_box2">4週目.</span>Facebook広告運営3週目</p>
			<div class="curriculum_detail clearfix">
				<div class="SectionTxt">
					<p class="">
4週目では、2週目～3週目で運営した広告の成果を分析し広告運営の改善に活かします。<br />
また、今後のFacebook広告運営の方針を決定します。
					</p>
				</div>
			<p class="catch curriculum_img3"><img src="images/curriculum_image4.png" alt=""/></p>
			<ul class="curriculum2_list">
				<li>広告運営の分析</li>
				<li>ターゲティングや配置や広告予算の見直しと改善</li>
				<li>ABテストの実施（バナー広告クリエイティブ・動画広告クリエイティブ）</li>
				<li>今後のFacebook広告運営の方針の決定</li>
			</ul>
			</div>
		</div>

		<p class="catch center"><img src="images/consulting_rule.png" alt=""/></p>

		<div class="content_box clearfix">
			<div class="SectionTxt">
		<p class="mg-b2">以上がFacebook広告4週間集中コンサルティングのカリキュラムです。<br />
この4週間のコンサルティングが終わるころには、<br />
きっとあなたはFacebook広告の運営の仕方を身に着けているでしょう。</p>
		<p class="mg-b2"><span class="yellow"><strong>このコンサルティングであなたが手に入れるのは【Facebook広告を使った無限の集客ノウハウ】です。<br />
広告費を投資すれば、あなたに代わってFacebookが半永久的に<br />
小予算で大量の顧客を連れて来てくれる“集客装置”になるからです。</strong></span></p>
		<p class="mg-b2">たしかに、ゼロからFacebook広告を運営して売れるアカウントに育てるには、時間も労力も必要です。<br />
しかし、それすらも、あなたには必要ありません…</p>
		<p class="mg-b2">なぜか？<br />
<span class="yellow"><strong>このFacebook広告の実践にあたって必要な全てのノウハウを、<br />
私が直接あなたにお伝えするのがこのコンサルティングの目的だからです。</strong></span></p>
<p class="mg-b2">従って、あなたはコンサルティングを受講して、私の解説を聞きながら、そのとおりに作業するだけ。<br />
<strong>「後は実践あるのみ！」という流れになります。</strong>	</p>
			</div>
		</div>

		<div class="user_box mg-t1 clearfix">
			<table>
			<thead>
			<tr>
			  <th>本コンサルティングの対象者です</th>
			</tr>
			</thead>
			<tbody>
			<tr>
				<td>
				  <ul class="user_list">
				    <li>Facebook広告に広告を出稿したことはあるけれど、<br />
もっと費用対効果の高いノウハウを身につけたい方</li>
				    <li>教材で独学したが、自分の広告運営のやり方が正しいか確認したい方</li>
				    <li>なるべく広告費をかけずに、たくさん商品やサービスを売れるようにしたい方</li>
				    <li>自社の商品やサービスに適したFacebook広告の運営の仕方を学びたい方</li>
				    <li>Facebook広告をはじめとして、ネット集客について相談したい方</li>
				  </ul>
				</td>
			</tr>
			</tbody>
			</table>
			<div class="SectionTxt mg-t1">
				<p class="mg-b2">これらの方が対象者です。<br />
				<p class="mg-b2"><span class="yellow"><strong>基本的なパソコン操作ができてネット集客に情熱のある方であれば、<br />
					Facebook広告を運営したことが無い方も歓迎します。</strong></span></p>					
				<p class="mg-b2"><strong>ただし、広告予算5万円は投資出来る方にお申し込み頂きたいと思います。</strong></p>	
				<p class="mg-b2">また、コーチ、コンサルタント、セミナー講師、著者、士業、治療家の方などに<br />
ぜひご受講頂きたいと思います。</p>
				<p>さらに、「Facebook広告の良い運用法を知りたい」<br />
「一度やってみたけど上手くいかなかった」というマーケティング担当者の方にも<br />
ぜひご受講頂きたいと思います。</p>
			</div>
		</div>

		<div class="feature_box mg-t2">
			<p class="catch center mg-t1  mg-b1"><img src="images/goal_catch.png" alt=""/></p>
			<div class="feature_detail SectionTxt clearfix">
				<p class="feature_img"><img src="images/goal_img1.png" alt=""/></p>
				<p class="feature_text">
				<div class="red bold list mg-b2">
					<ul>
						<li>1日500円からの小予算で新規顧客を獲得出来るようになること</li>
						<li>アカウント開設から効果的なクリエイティブの考え方、最適化、レポート作成までFacebook広告を運用するのに必要なスキルを身につけること</li>
						<li>広告代行業者に頼まなくても自力で広告を運営出来るようになること</li>
					</ul>
				</div>
				<p class="mg-b2">以上が本コンサルティングのゴールです。</p>
				<p class="mg-b2"><span class="yellow"><strong>【Facebook広告4週間集中コンサルティング】の個人指導は、<br />
					Facebook広告のご質問はもちろん、<br />
受講後の実際のFacebook広告の進め方や商品やサービスの販売方法に関するご質問まで多く頂き、<br />
内容に合わせて個別にサポートさせて頂きます。</strong></span></p>
				<p class="mg-b2">受講生の状況に合わせた柔軟なサポートが受けられることが最大の特徴です。</p>
				<p class="mg-b2">また、本コンサルティングでは、Facebook広告を活用して、<br />
顧客を増やしたい、売上を上げたいというニーズに対し、<br />
どのようにすれば費用対効果を上げられるかについて個別にアドバイスいたします。</p>
				<p>
<strong>ぜひ本コンサルティングを通して、あなた自身のビジネスにおいて、<br />
Facebook広告を活用して売上を上げるためのノウハウを身につけて頂きたいと思います。</strong></p>
				</p>
			</div>
		</div>

		<div class="after_box mg-t3">
			<p class="catch center mg-t1"><img src="images/after_catch.png" alt=""/></p>
			<div class="after_detail clearfix">
				<p class="fall_img mg-t3"><img src="images/after_img.png" alt=""/></p>
				<div class="after_text">
					<div class="SectionTxt mg-t1">
						<p class="mg-b2">こちらのコンサルティングを受講した後に、<br />
あなたがどのようになれるかのイメージをご紹介します。</p>
						<p class="mg-b2">例えばあなたが教材を販売していたとします。<br />
Facebook広告を利用してメルマガ登録者に教材を販売します。</p>
						<p class="mg-b2">本コンサルティング受講前は、<br />
Facebook広告でメルマガ登録者を、<br />
3千円で1件獲得出来ていたとします。</p>
						<p class="mg-b2">そして、毎月広告予算を30万円かけたとします。<br />
1カ月で100件のメルマガ登録者を獲得出来ています。</p>
						<p class="mg-b2">教材の価格は5万円で、メルマガ登録者の10％にお申し込み頂けるものとします。</p>
						<p class="mg-b2">すると、毎月、（100×0.1）人×5万円=50万円の売上になります。<br />
広告費を差し引けば、50万円-30万円=20万円が利益となります。</p>
						<p class="mg-b2">ここで、Facebook広告4週間集中コンサルティングで費用対効果の高い広告運営のノウハウを身に付けた後、<br />
1件あたりのメルマガ登録者の価格を低く抑えることが出来るようになったとします。</p>
						<p class="mg-b2"><strong>例えば、2千円でメルマガ登録者を1件獲得出来るようになったとすれば、<br />
1カ月で獲得出来るメルマガ登録者数は100件から150件と増えます。</strong></p>
						<p class="mg-b2"><span class="yellow"><strong>すると、毎月、（150×0.1）人×5万円=75万円と売上がアップします。<br />
広告費を差し引けば、75万円-30万円=45万円が利益となります。</strong></span></p>
						<p class="mg-b2"><strong>さらに、千円でメルマガ登録者を1件獲得出来るようになったとすれば、<br />
1カ月で獲得出来るメルマガ登録者数は300件に増えます。</strong></p>
						<p class="mg-b2"><span class="yellow"><strong>すると、毎月、（300×0.1）人×5万円=150万円と売上がアップします。<br />
広告費を差し引けば、150万円-30万円=120万円が利益となります。</strong></span></p>
						<p class="mg-b2">お取り扱いの商品・サービスやオプトインページの成約率にもよりますが、<br />
メルマガ登録者を数100円で獲得するのも夢ではありません。</p>
						<p class="mg-b2"><strong>なので、仮に500円でメルマガ登録者を1件獲得出来るようになったとすれば、<br />1カ月で獲得出来るメルマガ登録者数は600件に増えます。</strong></p>
						<p class="mg-b2"><span class="yellow"><strong>すると、毎月、（600×0.1）人×5万円=300万円と売上がアップします。<br />
広告費を差し引けば、300万円-30万円=270万円が利益となります。</strong></span></p>
						<p class="mg-b2">ようするに、顧客獲得単価を下げるほど、<br />
あなたのビジネスの利益率は拡大するのです。</p>
						<p class="mg-b2"><span class="yellow"><strong>本コンサルティング受講後のあなたは、このように<br />
Facebook広告を活用して利益率の高い<br />
ビジネスを展開することが出来るようになります。</strong></span></p>
						<p class="mg-b2">Facebook広告を活用した無限の集客ノウハウを身に着けたい方は、<br />
ぜひこの機会を逃さずご受講ください。</p>
					</div>
				</div>
			</div>
		</div>

		<p class="catch center mg-t1"><img src="images/mover_catch.png" alt=""/></p>

		<div class="feature_box mg-t2">
			<div class="feature_detail SectionTxt clearfix">
				<p class="feature_img"><img src="images/mover_img1.png" alt=""/></p>
				<p class="feature_text">
				<p class="mg-b2"><strong>実は、今、Facebook広告の最新のある機能を使うと、<br />
					費用対効果の高い広告運営が可能になります。</strong></p>
				<p class="mg-b2">ネット広告の代理店をはじめとして、<br />
					まだ導入している企業は極めてまれな広告配信の機能になります。</p>
				<p class="mg-b2"><span class="yellow"><strong>実際、弊社でこの機能を使ってみたところ、<br />
					他の配信に比較して、顧客獲得単価を3分の2まで抑えることに成功しています。</strong></span></p>
				<p class="mg-b2">なので、この機能を使いこなすことが出来れば、<br />
					あなたも先行者利益を得られることは間違いないでしょう。</p>
				<p class="mg-b2">ちなみにFacebook広告徹底ガイド動画講座でも未紹介の最新のノウハウになりますが、<br />
本コンサルティングでは、このノウハウをあなただけに伝授いたします。</p>
				<p class="mg-b1"><span class="yellow"><strong>詳細はコンサルティング時にご説明いたしますが、<br />
ぜひ他社が追従する前に最大の利益を得てください。</strong></span></p>
			</div>
		</div>

		<div class="feature_box mg-t2">
			<p class="catch center mg-t1  mg-b1"><img src="images/price_catch.png" alt=""/></p>
			<div class="feature_detail SectionTxt clearfix">
				<p class="feature_img"><img src="images/price_img1.png" alt=""/></p>
					<p class="mg-b2"><strong>それでは、いよいよ価格を発表いたします。</strong></p>

<p class="mg-b2"><span class="yellow"><strong>最初、このコンサルティングの価格は、<br />
100万円にさせて頂こうと考えました。</strong></span></p>

<p class="mg-b2"><strong>先程紹介した様なモデルでFacebook広告で顧客獲得単価を下げることに成功した場合、<br />
年間にして数百万円～数千万円の利益を得ることが出来ます。</strong></p>

<p class="mg-b2"><strong>そのために必要な知識の全てをお伝えし、<br />
共にFacebook広告を運営をする訳ですから、<br />
低価格でご提供出来るものではありません。</strong><br />
なので、100万円にさせて頂こうと思いました。</p>

<p class="mg-b2">しかし、今回は100万円にはしませんでした。</p>

<p class="mg-b2">ぜひこの特別な機会を少しでも多くの方に<br />
体験いただきやすい価格とさせて頂きたかったからです。</p>

<p class="mg-b2"><span class="yellow"><strong>そこで、次に考えた価格は、50万円でした。</strong></span></p>

<p class="mg-b2"><strong>50万円でしたら、明らかに元が取れるどころか、<br />
仮に先程紹介したようなモデルでFacebook広告の運営が成功したら、<br />
少なくとも数倍以上のリターンになるわけです。</strong><br />
ですから、50万円でしたら、受講生様にも納得いただけるはずだ、と考えました。</p>

<p class="mg-b2">ただし、50万円にはしませんでした。</p>

<p class="mg-b2">なぜなら、Facebook広告運営のノウハウで売上が激増するといっても、<br />
もしかしたら、今すぐに即金でお支払い出来ない方もおられる可能性があると考えたからです。</p>

<p class="mg-b2">せっかくFacebook広告の神髄を極めたいと真剣に考えておられる方がいる中で、<br />
その機会を逃されてしまうのは非常にもったいないと考えました。</p>

<p class="mg-b2"><span class="yellow"><strong>そこで、次に、30万円とさせて頂くことにしました。</strong></span></p>

<p class="mg-b2">私のコンサルティング料は1時間10万円になります。<br />
4週間集中のコンサルティングであれば、30万円は当然の価格です。</p>

<p class="mg-b2">しかし、30万円にはしませんでした。</p>

<p class="mg-b2">このFacebook広告4週間集中コンサルティングを通したアドバイスを行うことによって、<br />
全日本の中小企業様の売上貢献のお役に立ち、日本経済の発展に貢献したいと考えたのです。</p>

<p class="mg-b2"><span class="yellow"><strong>そのため、最終的な金額は、定価199,800円とさせて頂くことにしました。</strong></span><br />
これが、今回募集するコンサルティングの価格です。</p>

<p class="mg-b2"><span class="yellow"><strong>さらに、すでに弊社の「小予算で大量集客出来るようになる！<br />
Facebook広告徹底ガイド動画講座」をご購入の方には、<br />
定価から4万円値引きの159,800円にて本サービスをご提供します。</strong></span></p>

<p class="mg-b2">しかし、ご注意ください。<br />
<span class="yellow"><strong>受付できる受講生様の人数は先着10名様のみです。</strong></span><br />

<p class="mg-b2">Facebook広告4週間集中コンサルティングにおけるコンサルティングは、小池が直接担当させて頂きます。<br />
小池の時間資源にも限りがございますため、受付できる受講生様人数にも制限がございます。</p>

<p class="mg-b2"><span class="yellow"><strong>よって、本サービスは先着順で、10名様に達し次第、<br />
予告なく、申し込み受付を終了とさせて頂きます。<br />
そのため、本サービスにご関心をいただけた場合は、<br />
本日このタイミングで、お申し込みされることをお奨めいたします。</strong></span></p>

<p class="mg-b2"><span class="yellow"><strong>また、申し込み期間は本日6時～4日後24時の5日間とさせて頂きます。<br />
この5日間の申し込み期間を超えたら、二度と同じ価格条件で<br />
このコンサルティングをご受講頂くことは出来ません。</strong></span></p>
<p>ぜひ、今すぐ躊躇することなく、<br />
このページ下の申し込みフォームから必要事項を記入して、お申し込みください。</p>
			</div>
		</div>

		<div class="feature_box mg-t2">			
			<p class="catch center mg-t1  mg-b1"><img src="images/tokuten_catch.png" alt=""/></p>
			<div class="content_box clearfix">
				<div class="SectionTxt mg-t1">
					<p class="mg-b2"><span class="yellow"><strong>さらに、あなたに必ず成果を出して頂くための特典をご用意いたしました。</strong></span></p>
					<p class="mg-b2">正直申し上げて、ここまでの内容でも、<br />
	充分に成果を出せるものです。</p>
					<p class="mg-b2">しかし、このコンサルティングでは、<br />
	あなたが最大の成果を出せるような数々の特典も合わせてお渡しします。</p>
				</div>
			</div>
			<div class="tokuten_detail clearfix">
				<p class="tokuten_number"><img src="images/tokuten1.png" alt=""/></p>
				<p class="tokuten_img"><img src="images/tokuten1_img.png" alt=""/></p>
				<p class="tokuten_title">Facebook広告効果計測管理テンプレート</p>
				<p><span class="yellow"><strong>広告の効果を計測して管理できるエクセルシートをご提供することにいたしました。</strong></span>
このシートに必要事項を記入すれば、広告費をどれだけ投資すれば目標とする売上や利益を得られるかが一目瞭然で把握できます。</p>
			</div>
			<div class="tokuten_detail2 clearfix">
				<p class="tokuten_number"><img src="images/tokuten2.png" alt=""/></p>
				<p class="tokuten_img"><img src="images/tokuten2_img.png" alt=""/></p>
				<p class="tokuten_title">広告クリエイティブ×4点（バナー広告）</p>
				<p><span class="yellow"><strong>貴社のビジネスにあった反響の出るタイプの広告クリエイティブを弊社にて4点作成します。</strong></span>ぜひ費用対効果の高い広告運営の実現にお役立てください。</p>
			</div>
			<div class="tokuten_detail2 clearfix">
				<p class="tokuten_number"><img src="images/tokuten3.png" alt=""/></p>
				<p class="tokuten_img"><img src="images/tokuten3_img.png" alt=""/></p>
				<p class="tokuten_title">秘密のプレゼント</p>
				<p><span class="yellow"><strong>受講者様全員にもれなく「秘密のプレゼント」を用意しております。</strong></span>
秘密なので中身は言えませんが、必ずあなたに喜んでいただけるプレゼントです。もちろん、Facebook広告の費用対効果を2倍、3倍に引き上げるものです。ぜひ期待していてください。</p>
			</div>

			<div class="content_box clearfix">
				<p class="catch center mg-t1"><img src="images/final_catch.png" alt=""/></p>
				<div class="SectionTxt mg-t1">
					<p class="mg-b2">最後になりますが、私の経営に関する考え方をお話します。<br />
<span class="yellow"><strong>経営者にとって「集客」は永遠のテーマと考えています。</strong></span></p>
					<p class="mg-b2">というのも、どんなに素晴らしい商品であったとしても、<br />
それを購入頂けるお客様がいなければ、商売にはならないからです。<br />このことは、ここまでご覧頂いたあなたに説明する必要は無いでしょう。</p>
					<p class="mg-b2"><span class="yellow"><strong>しかし、多くの経営者が見落としている点があります。<br />
それは、“ビジネスで利益を上げるための真実”です。</strong></span></p>
					<p class="mg-b2"><strong>実は、いかなるビジネスであっても、利益を最大化するための方法は2つに別れるのです。<br />
1．顧客生涯価値※1（LTV：Life Time Value）を上げること<br />
2．顧客獲得単価※2（CPA:Cost Per Acquisition）を下げること</strong></p>
					<p class="mg-b2">※1.顧客1人あるいは1社の顧客ライフサイクル全期間で、<br />
						その顧客が企業にもたらした価値の総計のこと。通常は1年間で考える。<br />
※2.顧客1人あるいは1社を獲得するのに必要な費用のこと。
					</p>
					<p class="mg-b2">もちろん、両方やらなければいけないことですが、<br />
多くの経営者が「2」の顧客獲得単価を下げることに無頓着なのです。</p>
					<p class="mg-b2">おそらくは「1」に比重を置いている経営者の方が圧倒的に多いのではないでしょうか。</p>
					<p class="mg-b2">いずれにせよ、今よりも利益を上げたければ、<br />
「1」を今よりもやるか、「2」を今よりもやるかしかないわけです。</p>
					<p class="mg-b2">さて、あなたはどちらの選択肢を選びますか？</p>
					<p class="mg-b2">もし、「1」の顧客生涯価値を上げることを選択した場合、単純計算で、<br />
今の商品やサービスの価格を2倍上げるか、新しい商品やサービスが必要になります。</p>
					<p class="mg-b2"><strong>しかし、「それが果たして可能なのか？」というところで、<br />
経営者の誰もが“現実の壁”に直面するわけです。</strong></p>
					<p class="mg-b2">物やサービスに溢れた日本で商売を続けている経営者の方々は、<br />
現時点で少しでも高く売ろうと工夫したり、新商品開発に苦心していることでしょう。</p>
					<p class="mg-b2"><strong>一方で、「2」の顧客獲得単価を下げることを選択した場合、<br />
2倍売上を上げたければ顧客獲得単価を半分に下げれば良いわけですし、<br />
3倍売上を上げたければ顧客獲得単価を3分の1に下げれば良いのです。</strong></p>
					<p class="mg-b2">ただし、今度はノウハウという“現実の壁”に直面することになります。</p>
					<p class="mg-b2"><span class="yellow"><strong>しかし、本コンサルティングであなたが手に入れる、<br />
【Facebook広告を活用した無限の集客ノウハウ】には、<br />
そうした“現実の壁”を破壊する力があります。</strong></span></p>
					<p class="mg-b2"><strong>なぜなら、本コンサルティングを受講したあなたは、<br />
“極限”まで顧客獲得単価を下げるノウハウを会得することになります。</strong></p>
					<p class="mg-b2"><strong>そのため、コンサルティングでご説明したとおりにFacebook広告を実践頂ければ、<br />
“小予算で大量集客する”ことが出来るのです。</strong></p>
					<p class="mg-b2"><span class="yellow"><strong>結果として、コンサルティングや広告に投資した費用の<br />
“100倍以上のリターン”を得ることが出来るでしょう。</strong></span></p>
					<p class="mg-b2">しかも、一度ノウハウを身に着けてしまえば、<br />
						広告を運営するのにそれほどの労力や時間は必要ありません。</p>
					<p class="mg-b2">つまり、実践さえすれば、あなたが休んでいる間にも、<br />
「利益」だけが上積みされていくのです。</p>
					<p class="mg-b2"><span class="yellow"><strong>なので、本コンサルティングでお伝えする<br />
【Facebook広告を活用した無限の集客ノウハウ】は、<br />
あなたが実践できる“最強の集客方法”なのです。</strong></span></p>
					<p class="mg-b2">このことに「間違い」がないか、<br />
もう1度このページを読み返してみてください。</p>
					<p class="mg-b2">読み返してみて、私の言っていることにご納得頂けたなら、<br />
決してあなたに後悔はさせません。</p>
					<p class="mg-b2">それだけの価値あるサービスとお約束いたします。<br />
是非この唯一無二のチャンスを活かして人生を変えるきっかけにしてください。</p>
				</div>
				<p class="right"><img src="images/sign.png" width="180" height="67"></p>
			</div>

		</div>

		<!--<p class="catch_timer center"><img src="images/catch1.png" alt="5日間限定先着10名様限定"/>
		<script src="countdown/js/soon.min.js"></script>
		<div class="soon" id="my-soon-counter"
		     data-due="2016-10-06T23:59:59"
		     data-event-complete="soonCompleteCallback"
		     data-layout="group"
		     data-format="d,h,m,s"
		     data-face="slot roll left fast"
		     data-visual="ring cap-round invert progressgradient-fb801b_f1d935 ring-width-custom">
		</div>-->

		<div id="form" class="application_box">

			<!--
			<div class="timer_1" id="sampleB"></div>
			<script language="JavaScript" type="text/javascript">
			<!--
			cdTimer1();
			 
			function cdTimer1()    {
			 
			// 設定項目 ここから---------------------------------------------
			    // タグ要素のID名
			    var    elemID = 'sampleB';
			 
			    // 期限日を設定
			    var    year    =    2016;            // 年
			    var    month    =    10;                // 月
			    var    day        =    7;                // 日
			 
			    // 期限終了後のメッセージ
			    var    limitMessage    =    '満員御礼！募集は終了しました！';
			 
			    // メッセージのスタイルクラス名（変更しない場合は空欄）
			    var    msgClass = 'msg_1';
			// 設定項目 ここまで---------------------------------------------
			 
			    var    timeLimit = new Date( year, month - 1, day );
			    var    timer = new CountdownTimer( elemID, timeLimit, limitMessage, msgClass );
			    timer.countDown();
			}
			 
			// 
			</script>-->

			<p class="catch center mg-b1"><img src="images/application_catch.png" alt=""/></p>

				<form action="mail.php" method="post" name="form_contact">
				<table class="application mg-b1">	
				<tbody>
				<tr>
					<th><strong>ご決済方法<br /><span class="red">※必須</span></strong></th>
					<td>
						<select name="contact_type1">
						  <option>銀行振り込み</option>
				 	 	</select>
					</td>
				</tr>
				<tr>
				<th><strong>御社名（店舗名）<br /><span class="red">※必須</span></strong></span></th>
				<td><input name="company" type="text" placeholder="例）合同会社Rutubo"></td>
				</tr>
				<tr>
				<th><strong>氏名<br /><span class="red">※必須</span></strong></th>
				<td><input name="name" type="text" placeholder="例）山田　太郎"></td>
				</tr>
				<tr>
				<th><strong>メールアドレス<br /><span class="red">※必須</span></strong></th>
				<td><input name="email" type="text" placeholder="例）sample@sample.com"></td>
				</tr>
				<tr>
				<th><strong>電話番号<br /><span class="red">※必須</span></strong></th>
				<td><input name="tel" type="text" placeholder="例）03-5283-6242"></td>
				</tr>
				<tr>
				<th><strong>郵便番号<br /><span class="red">※必須</span></strong></th>
				<td><input name="zip" type="text" placeholder="例）104-0061"></td>
				</tr>
				<tr>
				<th><strong>住所</strong></th>
				<td><input name="address" type="text" placeholder="例）東京都中央区銀座１丁目３番３号"></td>
				</tr>
				<tr>
				<th><strong>ホームページURL</strong></th>
				<td><input name="url" type="text" placeholder="例）http://www.web-rutubo.com"><br>※ホームページを既にお持ちの方のみ。</td>
				</tr>
				<tr>
				<th><strong>Facebook広告徹底ガイド動画講座購入の有無<br /><span class="red">※必須</span></strong></th>
					<td>
						<ul>
							<li><input type="radio" id="contact_type1" name="contact_type2" value="購入済み" checked="checked"><label for="contact_type1">購入済み</label></li>
							<li><input type="radio" id="contact_type2" name="contact_type2" value="未購入"><label for="contact_type2">未購入</label></li>
							</li>
						</ul>
					</td>
				</tr>
				<tr>
				<th><strong>備考<br />
コンサルティングへの期待や、現在の事業状況など、また、どんな結果を得たいのかなどをご記入ください。<br /><span class="red">※必須</span></strong></th>
				<td><textarea cols="30" name="comment" rows="10"></textarea></td>
				</tr>
				</tbody>
				<tr>
				<th><strong>規約の同意<br /><span class="red">※必須</span></strong></th>
					<td>
						<ul>
							<li><input type="checkbox" id="legal" name="legal" value="規約に同意します" ><label for="legal">規約に同意します</label></li>
							</li>
<p class="underline">当社規約は、必ず詳細までご確認頂いた上でお申し込みください。本サービスにお申し込み頂いた場合は、規約に完全に同意頂いたこととさせて頂きますので、ご注意ください。 </p>
						</ul>
					</td>
				</tr>
				</table>

				<div class="policy_outline">
				<p class="font14b">当社規約</p>
					<table border="0" cellspacing="0" cellpadding="10">
					  <tr align="left" valign="top">
					    <td><p><span class="font14b">【規約について】</span><br />
					        <span class="font12-last">※本コンサルティングは、先にご入金頂いたお客様を優先してお受けさせて頂きます。定員に達した後にお申し込みされたお客様のご依頼をお断りさせて頂く場合がございますため、いったんご入金頂いた本コンサルティングの費用については、ご返金を承っておりません。この点につきまして、あらかじめご了承ください。ただし、事業内容や事業状況によっては、実施前にコンサルティングをお断りさせて頂く場合がございます。その際には、ご入金頂いた全額を、お断りさせて頂いた日から3営業日以内に必ず全額をご返金させて頂きます。なお、お断りさせて頂く場合の説明義務は負わないものとさせて頂きます。 </span></p>
					      	<br />
					      	<p class="font12-last"><span class="font14b">■　お支払い方法につきまして</span><br />
					お申込し後、受付確認の自動返信メールの中で、銀行振込先のご案内をさせて頂きますのでお申し込み日から3日以内にお振込みください。</p>
					     </td>
					  </tr>
					</table>
				</div>

				<div class="center">
				<!--<input class="button mg-t1" name="submit" type="image" id="btnSubmit" value="&#20170;&#12377;&#12368;&#28961;&#26009;&#12391;&#30331;&#37682;&#12377;&#12427;"  krydebug="1751" src="images/btn.png" onmouseover="this.src='images/btn_on.png'" onmouseout="this.src='images/btn.png'"  onclick="ga('send', 'event', 'click', 'main', 'main1');" />-->
				<div class="center mg-t1">
					<!--<div class="general-button">
					  <div class="button-content">
					    <span class="icon-font">good</span>
					    <span class="button-text">今すぐお申し込みする</span>
					  </div>
					</div>-->
					<button type="submit" class="general-button form-button">
					  <div class="button-content">
					    <span class="icon-font">good</span>
					    <span class="button-text">今すぐ申し込む</span>
					  </div>
					</button>
				</div>
				</div>
			</form>
		</div>

		<div class="faq_box mg-t3">
			<p class="catch center mg-t1"><img src="images/faq_catch.png" alt=""/></p>
			<div class="faq_detail clearfix">
				<p class="faq_q">パソコン初心者ですが、大丈夫でしょうか？受講に当たり何か条件はありますか？</p>
				<p class="faq_a">基本的なパソコン操作（メール、スカイプ等）が出来て、意欲の高い方であれば歓迎します。<br />
					また、コンサルティング期間中に広告予算5万円の投資は出来る方が対象になります。</p>
				<p class="faq_q mg-t1">どのようなスケジュールでコンサルティング進めますか？</p>
				<p class="faq_a">4週間の間で行います。期間中の日程は受講生様のご都合に合わせます。</p>
				<p class="faq_q mg-t1">スカイプコンサルティングを希望する場合、どのように連絡すればよいのですか？</p>
				<p class="faq_a">初回はメールにて、info@rutubo-consulting.jp宛にアポイントメントのご希望日程・時間をご連絡頂きます。その後、当社から調整した日程をお伝えします。スカイプコンサルティング当日は、代表の小池が直接スカイプにてアドバイスをさせて頂きます。次回以降の予約は小池に直接ご連絡くださいませ。</p>
				<p class="faq_q mg-t1">スカイプコンサルティングは、どのくらいの時間、相談に応じて頂けるのでしょうか。</p>
				<p class="faq_a">今回のコンサルティングの1回あたりのアポイントメントは120分単位のお時間を設定させて頂きます。1週間に1回のスカイプコンサルティングを行い、4週間の内に合計4回のコンサルティングを行います。</p>
				<p class="faq_q mg-t1">メールコンサルティングを希望する場合、どのように連絡すればよいのですか？</p>
				<p class="faq_a">メールでの質問やご相談事項が発生した場合は、info@rutubo-consulting.jp宛までメールをお送りください。1営業日以内には、代表の小池からご相談事項にメールにてご回答させて頂きます。</p>
				<p class="faq_q mg-t1">コンサルティング受講期間中の相談回数に、制限はあるのでしょうか？</p>
				<p class="faq_a">メールでのご相談回数は、コンサルティング受講中は無制限とさせて頂きます。</p>
				<p class="faq_q mg-t1">支払い方法を教えてください。</p>
				<p class="faq_a">銀行振込でのお支払いになります。</p>
				<p class="faq_q mg-t1">返金保証はありますか？</p>
				<p class="faq_a">
本コンサルティングは、先にご入金頂いたお客様を優先してお受けさせて頂きます。
定員に達した後にお申し込みされたお客様のご依頼をお断りさせて頂く場合がございますため、いったんご入金頂いた本コンサルティングの費用については、ご返金を承っておりません。
この点につきまして、あらかじめご了承ください。
				</p>
				<p class="faq_q mg-t1">2名での参加は可能でしょうか？</p>
				<p class="faq_a">2名でご参加頂く場合は、1名様は特別割引価格159,800円（税込）にてご参加頂くことが可能です。その旨、お申し込みフォーム欄にてお知らせくださいませ。</p>
				<p class="faq_q mg-t1">期間延長は可能でしょうか？</p>
				<p class="faq_a">本コンサルティングは基本的に4週間で満了となります。延長を希望される方は、個別にご相談くださいませ。</p>
			</div>
		</div>

		<div class="content_box clearfix">
				<p class="catch center"><img src="images/final_catch.png" alt=""/></p>
			<div class="SectionTxt mg-t1">
				<p class="mg-b2"><strong>P.S.</strong></p>

<p class="mg-b2"><span class="yellow"><strong>ぜひ一度、このコンサルティングの費用対効果を考えてみてください。</strong></span></p>
<p class="mg-b2"><strong>先程紹介した様なモデルでFacebook広告で顧客獲得単価を下げることに成功した場合、<br />
年間にして数百万円～数千万円の利益を得ることが出来ます。</strong></p>
<p class="mg-b2"><strong>一方で、本コンサルティングの価格は199,800円、<br />
Facebook広告徹底ガイド動画講座をご購入頂いている方でしたら159,800円です。</strong></p>
<p class="mg-b2"><span class="yellow"><strong>ようするに、あなたが今、お申し込みを決断しさえすれば、<br />
コンサルティング料の100倍以上のリターンを手にすることが出来るということです。</strong></span></p>
<p class="mg-b2"><strong>しかもこのノウハウは一生のものになります。<br />
あなたが熱心な経営者であれば、どうしてこの機会を見逃すことが出来るでしょうか？</strong></p>
<p class="mg-b2"><span class="yellow"><strong>大切なことなので、再度お伝えさせて頂きますが、<br />
いかなるビジネスであっても顧客獲得単価を下げることは成功するために必須です。</strong></span></p>
<p class="mg-b2"><strong>顧客獲得単価を下げることで、小予算で大量に顧客を獲得出来るようになり、<br />
あなたのビジネスに勢いが生まれるのです。</strong></p>
<p class="mg-b2"><span class="yellow"><strong>イメージしてみてください。これからFacebook広告によって、<br />
安定的に、そして継続的に、大量の優良顧客から問い合わせが入ってくる状態を、です。<br />
ストレス要因だった飛び込み訪問もテレアポも一切せずに、<br />
広告費を投資すれば自動的に商品やサービスが売れていくという状態を、です。</strong></span></p>
<p class="mg-b2"><strong>そんな理想的な人生に導くチャンスが、今あなたの目の前にあります。<br />
ぜひこのチャンスを逃さず手中に収めてください。</strong></p>
<p class="mg-b2">本コンサルティングにご参加頂けるあなたの人生の成功を私は全身全霊で応援いたします。<br />
「Facebook広告4週間集中コンサルティング」であなたにお会いできる事を楽しみにしています。</p>
			</div>
		</div>

		<div class="mg-t1 mg-b2 center">
			<div class="general-button2">
				<button type="button" onclick="location.href='#form'" class="general-button">
				  <div class="button2-content">
				    <span class="icon2-font">good</span>
				    <span class="button2-text">ＦＢ広告4週間集中コンサルティングに申し込む</span>
				  </div>
				</button>		  
			</div>
		</div>

	</section>

	</div>

</div>

<footer>

<div id="footer">
	<div id="fbottom">
		<div id="frule">
			<ul>
				<li><a href="http://www.rutubo-consulting.jp/about-us/" target="_blank">運営会社</a></li>
				<li><a href="http://www.rutubo-consulting.jp/law/" target="_blank">特定商取引に基づく表示</a></li>
				<li><a href="http://www.rutubo-consulting.jp/privacy/" target="_blank">プライバシーポリシー</a></li>
			</ul>
		</div>
		<div class="fwrap">
			<p id="fcopy"><strong>Rutubo Consulting</strong></p>
			<p id="copyright"><small>&copy;2011~2016 Rutubo.LLC All Rights Reserved.</small></p>
		</div>
	</div>
</div>

</footer>

</body>
</html>