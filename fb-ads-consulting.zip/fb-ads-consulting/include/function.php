<?php
//アラート後ページ遷移
function cjdirect($str,$url) {
	echo "<script type='text/javascript'>alert('$str');window.location.href='$url';</script>";
}

//ページ遷移
function redirect($url){
	echo "<script type='text/javascript'>window.location.href='$url';</script>";
}

//フォーム値
function unhtml($content){
	$content=htmlspecialchars($content,ENT_QUOTES);
	$content=str_replace("'",'"',$content);
	if (mb_strlen($content,"UTF-8")>10000) $content=mb_substr($content,0,10000,"UTF-8");
	return trim($content);
}

//改行有効表示　改行・全角スペース・半角スペースx2->改行
function br($str) {
	$str=str_replace(array("\r\n","\r","\n"), "<br />", $str);
	$str=str_replace("　", "<br />", $str);
	$str=str_replace("  ", "<br />", $str);
	return $str;
}

//改行除去　改行なし
function nobr($str) {
	$str=str_replace(array("\r\n","\n","\r"),'',$str);
	return $str;
}

//カナ変換
function kana($str) {
	$arr = array('ｶﾞ' => 'ガ', 'ｷﾞ' => 'ギ', 'ｸﾞ' => 'グ', 'ｹﾞ' => 'ゲ', 'ｺﾞ' => 'ゴ',
                 'ｻﾞ' => 'ザ', 'ｼﾞ' => 'ジ', 'ｽﾞ' => 'ズ', 'ｾﾞ' => 'ゼ', 'ｿﾞ' => 'ゾ',
                 'ﾀﾞ' => 'ダ', 'ﾁﾞ' => 'ヂ', 'ﾃﾞ' => 'デ', 'ﾄﾞ' => 'ド', 'ﾊﾞ' => 'バ',
                 'ﾋﾞ' => 'ビ', 'ﾌﾞ' => 'ブ', 'ﾍﾞ' => 'ベ', 'ﾎﾞ' => 'ボ', 'ｳﾞ' => 'ヴﾞ',
	);
	return strtr($str, $arr);
}
	
//前ページ遷移
function back(){
 echo "<script type='text/javascript'>window.history.back();</script>";
}

//現在日時取得
function now(){
 echo date('Y/m/d H:i:s');
}

?>