<?php
class Upload{
	private $saveName;// 保存名
	private $savePath;// 保存路径
	private $maxSize = 0;// 文件最大字节
	private $fileFormat = array('image/gif','image/png','image/jpg','image/jpeg','application/x-shockwave-flash','application/msword','application/rar');// 文件格式&MIME限定
	private $overwrite = 0;// 覆盖模式
	public $ext;// 文件扩展名
	private $small = 0;// 是否生成缩略图；0否1是
	private $smallWidth = 130;// 缩略图宽
	private $smallHeight = 130;// 缩略图高
	private $smallPrefix = "small_";// 缩略图前缀
	private $errno;// 错误代号
	public $returnArray= array();// 所有文件的返回信息
	public $returninfo= array();// 每个文件返回信息

// 构造函数
// @param $savePath 文件保存路径
// @param $fileFormat 文件格式限制数组
// @param $maxSize 文件最大尺寸
// @param $overwriet 是否覆盖 1 允许覆盖 0 禁止覆盖
	function Upload($savePath, $fileFormat='',$maxSize = 0, $overwrite = 0) {
		$this->setSavepath($savePath);
		$this->setFileformat($fileFormat);
		$this->setMaxsize($maxSize);
		$this->setOverwrite($overwrite);
		$this->setSmall($this->small, $this->smallWidth,$this->smallHeight);
		$this->errno = 0;
	}
// 创建文件夹函数
// @param $path 文件路径
// @param $mode 权限
	function _mkdir($path, $mode = 0777) {
        $old = umask(0);//umask() 函数改变当前的 umask=0,所有人都具有读写权限。
        $res = @mkdir($path, $mode);
        umask($old);
        return $res;
    }
// 递归创建文件夹函数
// @param $path 文件路径
// @param $mode 权限
    function rmkdir($path, $mode = 0777) {
        return is_dir($path) || ( $this->rmkdir(dirname($path), $mode) && $this->_mkdir($path, $mode) );
    }
// 设置保存路径
// @param $savePath 文件保存路径：以 "/" 结尾，若没有 "/"，则补上
	function setSavepath($savePath){
		$this->savePath = substr( str_replace("\\","/", $savePath) , -1) == "/"
		? $savePath : $savePath."/";
	}
// 设置文件保存名
// @param $saveName 保存名，如果为空，则系统自动生成一个随机的文件名
	function setSavename($saveName){
		if ($saveName == ''){  // 如果未设置文件名，则生成一个随机文件名
			$name = date('YmdHis')."_".rand(100,999).'.'.$this->ext;
		} else {
			$name = $saveName;
		}
		$this->saveName = $name;
	}
// 设置缩略图
// @param $small = 1 产生缩略图 $smallWidth,$smallHeight 是缩略图的宽和高
	function setSmall($small, $smallWidth = 0,$smallHeight = 0){
		$this->small = $small;
		if($smallWidth) $this->smallWidth = $smallWidth;
		if($smallHeight) $this->smallHeight = $smallHeight;
	}
// 设置上传文件的最大字节限制
// @param $maxSize 文件大小(bytes) 0:表示无限制
	function setMaxsize($maxSize){
		$this->maxSize = $maxSize;
	}
// 设置文件格式限定
// @param $fileFormat 文件格式数组
	function setFileformat($fileFormat){
		if(is_array($fileFormat)){$this->fileFormat = $fileFormat ;}
	}

// 设置覆盖模式
// @param overwrite 覆盖模式 1:允许覆盖 0:禁止覆盖
	function setOverwrite($overwrite){
		$this->overwrite = $overwrite;
	}
// 文件格式检查,MIME检测
	function validateFormat(){
		if(!is_array($this->fileFormat)
			|| !in_array(strtolower($this->ext), $this->fileFormat)
			|| !in_array(strtolower($this->returninfo['type']), $this->fileFormat) )
			return true;
		else
			return false;
	}
// 获取文件扩展名
// @param $fileName 上传文件的原文件名
	function getExt($fileName){
		$ext = explode(".", $fileName);
		$ext = $ext[count($ext) - 1];
		$this->ext = strtolower($ext);
	}
// 删除文件
// @param $fileName 所要删除的文件名
	function del($fileName){
		if(!@unlink($fileName)){
			$this->errno = 15;
			return false;
		}
		return true;
	}

// 返回上传文件的信息
	function getInfo(){
		return $this->returnArray;
	}

// 得到错误信息
	function errmsg(){
		$uploadClassError = array(
			0	=>'没有任何错误，文件上传成功. ',
			1	=>'上传的文件超过了php.ini中upload_max_filesize指令限制.',
			2	=>'上传的文件超过了HTML表单中指定的MAX_FILE_SIZE限制',
			3	=>'文件仅部分被上传. ',
			4	=>'没有文件上传. ',
			6	=>'临时文件夹不存在，请查看php.ini中的设置. ',
			7	=>'无法写入文件到磁盘，查看文件读写权限. ',
			10	=>'输入的名字是不是无法使用!',
			11	=>'上传文件类型不符合规定!',
			12	=>'文件夹没有读写权限!',
			13	=>'文件已经存在!',
			14	=>'文件过大!',
			15	=>'删除文件失败!',
			16	=>'PHP服务器版本不支持gif文件创建函数，请检查GD库.',
			17	=>'PHP服务器版本不支持jpg文件创建函数,请检查GD库.',
			18	=>'PHP服务器版本不支持图像文件创建函数，请检查GD库.',
			19	=>'试图复制图片时候发生错误，PHP服务器版本不支持图片复制函数，请检查GD库',
			20	=>'新建一个真彩色图像时候发生错误，请检查GD库.',
			21	=>'试图缩放图像时候发生错误，请检查GD库.',
			22	=>'保存缩略图时候发生错误，查看缩略图文件夹是否具备读写权限?',
			);
		if ($this->errno == 0)
			return false;
		else
			return $uploadClassError[$this->errno];
	}
// 单个文件上传
// @param $fileArray 文件信息数组
	function copyfile($fileArray){
		$this->returninfo = array();
		// 返回信息
		$this->returninfo['name'] = $fileArray['name'];
		$this->returninfo['saveName'] = $this->saveName;
		$this->returninfo['size'] = number_format( ($fileArray['size'])/1024 , 0, '.', ' ');//以KB为单位
		$this->returninfo['type'] = $fileArray['type'];

		$this->getExt($this->returninfo['name']);
		// 检查文件格式
		if ($this->validateFormat()==false){
			$this->errno = 11;
			return false;
		}
		// 检查目录是否可写
		if(!@is_writable($this->savePath)){
		    $this->rmkdir($this->savePath);
		}
		// 如果不允许覆盖，检查文件是否已经存在
		if($this->overwrite == 0 && @file_exists($this->savePath.$fileArray['name'])){
			$this->errno = 13;
			return false;
		}
		// 如果有大小限制，检查文件是否超过限制
		if ($this->maxSize != 0 ){
			if ($fileArray["size"] > $this->maxSize){
				$this->errno = 14;
				return false;
			}
		}
		// 文件上传
		if(!@move_uploaded_file($fileArray["tmp_name"], $this->savePath.$this->saveName)){
			$this->errno = $fileArray["error"];
			return false;
		}elseif( $this->small ){// 创建缩略图
			$CreateFunction = "imagecreatefrom".($this->ext == 'jpg' ? 'jpeg' : $this->ext);
			$SaveFunction = "image".($this->ext == 'jpg' ? 'jpeg' : $this->ext);
			if (strtolower($CreateFunction) == "imagecreatefromgif"
				&& !function_exists("imagecreatefromgif")) {
				$this->errno = 16;
				return false;
			} elseif (strtolower($CreateFunction) == "imagecreatefromjpeg"
				&& !function_exists("imagecreatefromjpeg")) {
				$this->errno = 17;
				return false;
			} elseif (!function_exists($CreateFunction)) {
				$this->errno = 18;
				return false;
			}

			$Original = @$CreateFunction($this->savePath.$this->saveName);
			if (!$Original) {$this->errno = 19; return false;}
			$originalHeight = ImageSY($Original);
			$originalWidth = ImageSX($Original);
			$this->returninfo['originalHeight'] = $originalHeight;
			$this->returninfo['originalWidth'] = $originalWidth;
			if (($originalHeight < $this->smallHeight
				&& $originalWidth < $this->smallWidth)) {
				// 如果比期望的缩略图小，那只Copy
				copy($this->savePath.$this->saveName,
					$this->savePath.$this->smallPrefix.$this->saveName);
			} else {
				if( $originalWidth > $this->smallWidth ){// 宽 > 设定宽度
					$smallWidth = $this->smallWidth ;
					$smallHeight = $this->smallWidth * ( $originalHeight / $originalWidth );
					if($smallHeight > $this->smallHeight){// 高 > 设定高度
						$smallWidth = $this->smallHeight * ( $smallWidth / $smallHeight );
						$smallHeight = $this->smallHeight ;
					}
				}elseif( $originalHeight > $this->smallHeight ){// 高 > 设定高度
					$smallHeight = $this->smallHeight ;
					$smallWidth = $this->smallHeight * ( $originalWidth / $originalHeight );
					if($smallWidth > $this->smallWidth){// 宽 > 设定宽度
						$smallHeight = $this->smallWidth * ( $smallHeight / $smallWidth );
						$smallWidth = $this->smallWidth ;
					}
				}
				if ($smallWidth == 0) $smallWidth = 1;
				if ($smallHeight == 0) $smallHeight = 1;
				$createdsmall = imagecreatetruecolor($smallWidth, $smallHeight);
				if ( !$createdsmall ) {$this->errno = 20; return false;}
				if ( !imagecopyresampled($createdsmall, $Original, 0, 0, 0, 0,
					$smallWidth, $smallHeight, $originalWidth, $originalHeight) )
					{$this->errno = 21; return false;}
				if ( !$SaveFunction($createdsmall,
					$this->savePath.$this->smallPrefix.$this->saveName) )
					{$this->errno = 22; return false;}
			}
		}
	    return true;
	}
// 上传
// @param $fileInput 网页Form(表单)中input的名称
// @param $changeName 是否更改文件名
	function run($fileInput,$changeName = 1){
		if(isset($_FILES[$fileInput])){
			$fileArr = $_FILES[$fileInput];
			if(is_array($fileArr['name'])){//上传同文件域名称多个文件
			    $fileArrnum=count($fileArr['name']);
				for($i = 0; $i < $fileArrnum; $i++){
					$ar['tmp_name'] = $fileArr['tmp_name'][$i];
					$ar['name'] = $fileArr['name'][$i];
					$ar['type'] = $fileArr['type'][$i];
					$ar['size'] = $fileArr['size'][$i];
					$ar['error'] = $fileArr['error'][$i];
					$this->getExt($ar['name']);//取得扩展名，赋给$this->ext，下次循环会更新
					$this->setSavename($changeName == 1 ? '' : $ar['name']);//设置保存文件名
					if($this->copyfile($ar)){
						$this->returnArray[] =  $this->returninfo;
					}else{
						$this->returninfo['error'] = $this->errmsg();
						$this->returnArray[] =  $this->returninfo;
					}
				}
				return $this->errno ?  false :  true;
			}else{//上传单个文件
				$this->getExt($fileArr['name']);//取得扩展名
				$this->setSavename($changeName == 1 ? '' : $fileArr['name']);//设置保存文件名
				if($this->copyfile($fileArr)){
					$this->returnArray[] =  $this->returninfo;
				}else{
					$this->returninfo['error'] = $this->errmsg();
					$this->returnArray[] =  $this->returninfo;
				}
				return $this->errno ?  false :  true;
			}
			return false;
		}else{
			$this->errno = 10;
			return false;
		}
	}
}
?>