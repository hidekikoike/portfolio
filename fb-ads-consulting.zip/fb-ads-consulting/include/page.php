<?php
/*
function getPage($num, $perpage, $curpage, $mpurl) {
$Paginationpage = '&nbsp;';
	$mpurl .='?';
	if($num > $perpage) {
		$page = 10;
		$offset = 0;
		$pages = @ceil($num / $perpage);
		if($page > $pages) {
			$from = 1;
			$to = $pages;
		} else {
			$from = $curpage - $offset;
			$to = $curpage + $page - $offset - 1;
			if($from < 1) {
				$to = $curpage + 1 - $from;
				$from = 1;
				if(($to - $from) < $page && ($to - $from) < $pages) {
					$to = $page;
				}
			} elseif($to > $pages) {
				$from = $curpage - $pages + $to;
				$to = $pages;
				if(($to - $from) < $page && ($to - $from) < $pages) {
					$from = $pages - $page + 1;
				}
			}
		}

	    $Paginationpage .= $curpage > 1 ? '&nbsp;<a href="'.$mpurl.'page='.($curpage-1).'" >< 前</a>&nbsp;' : '&nbsp;<span class="current">< 前</span>';
		for($i = $from; $i <= $to; $i++) {
			$Paginationpage .= $i == $curpage ? '&nbsp;<span class="current">'.$i.'</span>' : '&nbsp;<a href="'.$mpurl.'page='.$i.'" >'.$i.'</a>&nbsp;';
		}
	    $Paginationpage .= $curpage < $pages ? '&nbsp;<a href="'.$mpurl.'page='.($curpage+1).'" >次 ></a>&nbsp;' : '&nbsp;<span class="current">次 ></span>';

$Paginationpage = $Paginationpage ? '該当数&nbsp;'.$num.'件&nbsp;'.$Paginationpage.'' : '';
} else {
	    $Paginationpage = '該当数&nbsp;'.$num.'件';
	}

return $Paginationpage;
}
*/
function getPageSearch($num, $perpage, $curpage, $mpurl) {
	$Paginationpage = '&nbsp;';
	$mpurl .='&';
	if($num > $perpage) {
		$page = 10;
		$offset = 0;
		$pages = @ceil($num / $perpage);
		if($page > $pages) {
			$from = 1;
			$to = $pages;
		} else {
			$from = $curpage - $offset;
			$to = $curpage + $page - $offset - 1;
			if($from < 1) {
				$to = $curpage + 1 - $from;
				$from = 1;
				if(($to - $from) < $page && ($to - $from) < $pages) {
					$to = $page;
				}
			} elseif($to > $pages) {
				$from = $curpage - $pages + $to;
				$to = $pages;
				if(($to - $from) < $page && ($to - $from) < $pages) {
					$from = $pages - $page + 1;
				}
			}
		}

	  $Paginationpage .= $curpage > 1 ? '&nbsp;<a href="'.$mpurl.'page='.($curpage-1).'" >< 前</a>&nbsp;' : '&nbsp;<span class="current">< 前</span>';
		
		for($i = $from; $i <= $to; $i++) {
			$Paginationpage .= $i == $curpage ? '&nbsp;<span class="current">'.$i.'</span>' : '&nbsp;<a href="'.$mpurl.'page='.$i.'" >'.$i.'</a>&nbsp;';
		}
	  $Paginationpage .= $curpage < $pages ? '&nbsp;<a href="'.$mpurl.'page='.($curpage+1).'" >次 ></a>&nbsp;' : '&nbsp;<span class="current">次 ></span>';
		$Paginationpage = $Paginationpage ? '該当数&nbsp;'.$num.'件&nbsp;'.$Paginationpage.'' : '';
	} else {
	  $Paginationpage = '該当数&nbsp;'.$num.'件';
	}
	return $Paginationpage;
}
/*
function Pagination($num, $perpage, $curpage, $mpurl) {
	$Paginationpage = '&nbsp;';
	$mpurl .='?';
	if($num > $perpage) {
		$page = 10;
		$offset = 0;
		$pages = @ceil($num / $perpage);
		if($page > $pages) {
			$from = 1;
			$to = $pages;
		} else {
			$from = $curpage - $offset;
			$to = $curpage + $page - $offset - 1;
			if($from < 1) {
				$to = $curpage + 1 - $from;
				$from = 1;
				if(($to - $from) < $page && ($to - $from) < $pages) {
					$to = $page;
				}
			} elseif($to > $pages) {
				$from = $curpage - $pages + $to;
				$to = $pages;
				if(($to - $from) < $page && ($to - $from) < $pages) {
					$from = $pages - $page + 1;
				}
			}
		}

	    $Paginationpage .= $curpage > 1 ? '&nbsp;<a href="'.$mpurl.'page='.($curpage-1).'" >< 前</a>&nbsp;' : '&nbsp;<span class="current">< 前</span>';
		for($i = $from; $i <= $to; $i++) {
			$Paginationpage .= $i == $curpage ? '&nbsp;<span class="current">'.$i.'</span>' : '&nbsp;<a href="'.$mpurl.'page='.$i.'" >'.$i.'</a>&nbsp;';
		}
	    $Paginationpage .= $curpage < $pages ? '&nbsp;<a href="'.$mpurl.'page='.($curpage+1).'" >次 ></a>&nbsp;' : '&nbsp;<span class="current">次 ></span>';
		$Paginationpage = $Paginationpage ? '<span class="disabled">該当数&nbsp;'.$num.'件</span>&nbsp;'.$Paginationpage.'' : '';
	} else {
	    $Paginationpage = '<span class="disabled">該当数&nbsp;'.$num.'件</span>';
	}
	return $Paginationpage;
}

function PageSearch($num, $perpage, $curpage, $mpurl) {
		$Paginationpage = '&nbsp;';
	$mpurl .='&';
	if($num > $perpage) {
		$page = 10;
		$offset = 0;
		$pages = @ceil($num / $perpage);
		if($page > $pages) {
			$from = 1;
			$to = $pages;
		} else {
			$from = $curpage - $offset;
			$to = $curpage + $page - $offset - 1;
			if($from < 1) {
				$to = $curpage + 1 - $from;
				$from = 1;
				if(($to - $from) < $page && ($to - $from) < $pages) {
					$to = $page;
				}
			} elseif($to > $pages) {
				$from = $curpage - $pages + $to;
				$to = $pages;
				if(($to - $from) < $page && ($to - $from) < $pages) {
					$from = $pages - $page + 1;
				}
			}
		}

	    $Paginationpage .= $curpage > 1 ? '&nbsp;<a href="'.$mpurl.'page='.($curpage-1).'" >< 前</a>&nbsp;' : '&nbsp;<span class="current">< 前</span>';
		for($i = $from; $i <= $to; $i++) {
			$Paginationpage .= $i == $curpage ? '&nbsp;<span class="current">'.$i.'</span>' : '&nbsp;<a href="'.$mpurl.'page='.$i.'" >'.$i.'</a>&nbsp;';
		}
	    $Paginationpage .= $curpage < $pages ? '&nbsp;<a href="'.$mpurl.'page='.($curpage+1).'" >次 ></a>&nbsp;' : '&nbsp;<span class="current">次 ></span>';
		$Paginationpage = $Paginationpage ? '<span class="disabled">該当数&nbsp;'.$num.'件</span>&nbsp;'.$Paginationpage.'' : '';
	} else {
	    $Paginationpage = '<span class="disabled">該当数&nbsp;'.$num.'件</span>';
	}
	return $Paginationpage;
}*/
?>
