<?php
include_once('resizeimg.class.php');

function up($source, $fname) {
	$RI = new resize_image();

	if (is_uploaded_file($source)) {

		//ファイルパス
		if($_SESSION['yuyan']=="JPN") {
			$upstr="";
		} else if($_SESSION['yuyan']=="CHN"){
			$upstr="chn/";
		} else if($_SESSION['yuyan']=="KOR"){
			$upstr="kor/";
		} else if($_SESSION['yuyan']=="ENG"){
			$upstr="eng/";
		}
		$path='../'.$upstr.'upload/ad/';

		//画像保存
		move_uploaded_file($source, $path.$fname);
		list($width, $height, $type,) = getimagesize($path.$fname);

		if ($type==1 || $type==2 || $type==3) {

			//画像ファイル名
			$new=date('YmdHis')."_".rand(100,999);
			switch ($type) {
				case 1:
					$ext='.gif';
					break;
				case 2:
					$ext='.jpg';
					break;
				case 3:
					$ext='.png';
					break;
			}
			$file=$path.$new.$ext;

			rename($path.$fname,$file);

			//サイズ確認
			$max1=600;
			$max2=450;
			$rate=$max2/$max1;
			$min=75;

			//画像サイズ
			if ($width>$height) {
				//横長画像
				if ($width>$max1 && $height>$max2) {
					//サイズオーバー
					$w = $max1;
					$h = $max2;
					$new_image_path = $RI->disp_resize_img_path( $file, $w, $h,'fit' );
				} else {
					//サイズオーバーなし
					if ($width*$rate<$height) {
						//縦をトリミング
						$w = $width;
						$h = floor($width*$rate);
						$new_image_path = $RI->disp_resize_img_path( $file, $w, $h, 'fit' );
					} else {
						//横をトリミング
						$w = floor($height/$rate);
						$h = $height;
						$new_image_path = $RI->disp_resize_img_path( $file, $w, $h, 'fit' );						
					}
					
				}
				
				//画像小
				if ($height>$min) {
					//サイズオーバー　縦を基準に縮小・横をトリミング
					$w = $min;
					$h = $min;
					$small_image_path = $RI->disp_resize_img_path( $file, $w, $h, 'fit' );
				} else {
					//サイズオーバーなし　横をトリミング
					$w = $height;
					$h = $height;
					$small_image_path = $RI->disp_resize_img_path( $file, $w, $h, 'fit' );
				}
				
			} else {
				//縦長画像
				if ($width>$max2 && $height>$max1) {
					//サイズオーバー
					$w = $max2;
					$h = $max1;
					$new_image_path = $RI->disp_resize_img_path( $file, $w, $h,'fit' );
				} else {
					//サイズオーバーなし
					if ($height*$rate<$width) {
						//横をトリミング
						$w = floor($height*$rate);
						$h = $height;
						$new_image_path = $RI->disp_resize_img_path( $file, $w, $h, 'fit' );
					} else {
						//縦をトリミング
						$w = $width;
						$h = floor($width/$rate);
						$new_image_path = $RI->disp_resize_img_path( $file, $w, $h, 'fit' );
					}
				}
				//画像小
				if ($width>$min) {
					//サイズオーバー　横を基準に縮小・縦をトリミング
					$w = $min;
					$h = $min;
					$small_image_path = $RI->disp_resize_img_path( $file, $w, $h, 'fit' );
				} else {
					//サイズオーバーなし　縦をトリミング
					$w = $width;
					$h = $width;
					$small_image_path = $RI->disp_resize_img_path( $file, $w, $h, 'fit' );
				}
			}

			
			//変換確認
			if ($new_image_path!=$file && $small_image_path!=$file) {
				@unlink($file);
				@rename( $new_image_path, $path.$new.'.jpg' );
				$small=$path.'small_'.$new.'.jpg';
				@rename( $small_image_path, $small );
				$return=$new.'.jpg';
			} else {
				@unlink($file);
				@unlink($new_image_path);
				@unlink($small_image_path);
				$return=false;
			}
		} else {
			@unlink($path.$fname);
			$return=false;
		}
	} else {
		$return=false;
	}
	return $return;
}
?>
