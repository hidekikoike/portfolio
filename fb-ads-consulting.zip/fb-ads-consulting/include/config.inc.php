<?php
define('SYS_DBHOST', 'mysql516.heteml.jp');
define('SYS_DBUSER', '_rutubo_webinar');
define('SYS_DBPW', '1205hide');
define('SYS_DBNAME', '_rutubo_webinar');
define('SYS_DBCHARSET', 'utf8');
