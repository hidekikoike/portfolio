<?php
if(!defined('SYS_DBHOST')) {
	exit('Access denied');
}
/**
機能：Databaseクラスアクションのベース
**/
class DBSQL{
	private $CONN = "";									//データベース接続の変数定義
	/**
	 * 機能：初期化コンストラクタ、データベースへの接続
	 */
	public function __construct(){
		try {											//接続エラーとエラーのファイルをキャッチ
			$conn = @mysql_connect(SYS_DBHOST, SYS_DBUSER, SYS_DBPW);
			if(!$conn) throw new Exception("Mysql Err!");
			try {											//データベースの選択エラーは、エラーファイルを取り込んで表示
		  	if(!@mysql_select_db(SYS_DBNAME,$conn)) throw new Exception("Database Err!");
			  mysql_query("set names ".SYS_DBCHARSET);
		    $this->CONN = $conn;
		  } catch (Exception $e) {
			  $msg = $e->getMessage();
			  $this->halt($msg);
		  }
		} catch (Exception $e){
			$msg = $e->getMessage();
			$this->halt($msg);
		}
	}


	/**
	 * 機能：データベースクエリ機能
	 * パラメータ：$sql SQLステートメント
	 * 戻る：2つの配列またはfalse
	 */
	public function select($sql = ""){
		if (empty($sql)) return false;					//SQLステートメントが空の場合、FALSE
		if (empty($this->CONN)) return false;			//接続が空の場合、FALSE
		try{											//データベースの選択エラーは、エラーファイルを取り込んで表示
			$results = @mysql_query($sql,$this->CONN);
			if(!$results) throw new Exception("sql err:".$sql);
		}catch (Exception $e){
			$msg = $e->getMessage();
			$this->halt($msg);
		}
		if ((!$results) or (empty($results))) {			//クエリの結果空の場合、FALSE
			@mysql_free_result($results);
			return false;
		}

		$count = 0;
		$data = array();

		while ($row = @mysql_fetch_array($results)) {	//結果を再形成する二次元配列
			$data[$count] = $row;
			$count++;
		}

		@mysql_free_result($results);

		return $data;
	}
	/**
	 * 機能：データの挿入機能
	 * パラメータ：$sql SQLステートメント
	 * 戻り値：0または新しく挿入されたデータID
	 */
	public function insert($sql = ""){
		if (empty($sql)) return 0;						//SQLステートメントが空の場合、FALSE
		if (empty($this->CONN)) return 0;				//接続が空の場合、FALSE
		try{											//データベースの選択エラーは、エラーファイルを取り込んで表示
			$results = mysql_query($sql,$this->CONN);
			if(!$results) throw new Exception("sql err:".$sql);
		}catch(Exception $e){
			$msg = $e->getMessage();
			$this->halt($msg);
		}
		if (!$results) 									//インサートの結果失敗は0を返し、そうでなければ、データIDを返す
			return 0;
		else
			return @mysql_insert_id($this->CONN);
	}

	/**
	 * 機能：データの更新機能
	 * パラメータ：$sql SQLステートメント
	 * 戻り値：TRUE OR FALSE
	 */
	public function update($sql = ""){
		if(empty($sql)) return false;					//SQLステートメントが空の場合、FALSE
		if(empty($this->CONN)) return false;			//接続が空の場合、FALSE
		try{											//データベースの選択エラーは、エラーファイルを取り込んで表示
			$result = mysql_query($sql,$this->CONN);
			if(!$result) throw new Exception("sql err:".$sql);
		}catch(Exception $e){
			$msg = $e->getMessage();
			$this->halt($msg);

		}
		return $result;
	}
	/**
	 * 機能：データの削除機能
	 * パラメータ：$sql SQLステートメント
	 * 戻り値：TRUE OR FALSE
	 */
	public function delete($sql = ""){
		if(empty($sql)) return false;					//SQLステートメントが空の場合、FALSE
		if(empty($this->CONN)) return false;			//接続が空の場合、FALSE
		try{
			$result = mysql_query($sql,$this->CONN);
			if(!$result) throw new Exception("sql err:".$sql);
		}catch(Exception $e){
			$msg = $e->getMessage();
			$this->halt($msg);
		}
		return $result;
	}
	/**
	 * 機能：トランザクションを定義する
	 */
	public function begintransaction()
	{
		mysql_query("SET  AUTOCOMMIT=0");				//デフォルトのMySQLの即時実行のため、自動的にコミットしないように設定
		mysql_query("BEGIN");							//トランザクションの定義開始
	}
	/**
	 * 機能：ロールバック
	 */
	public function rollback()
	{
		mysql_query("ROOLBACK");
	}
	/**
	 * 機能：コミット
	 */
	public function commit()
	{
		mysql_query("COMMIT");
	}
	/**
	 * 機能：指定のレコードIDを抽出するためのテーブルを指定
	 * パラメータ：$id テーブルID, $name テーブル名
	 * 戻り値：配列
	 */
	public function getInfo($name,$id)
	{
		$sql = "SELECT * FROM " . $name . " WHERE ID = $id";
		$r = $this->select($sql);
		return $r[0];
	}

	public function halt($msg)
	{
	   echo $msg;
	}
	
	public function insertData($name,$data)
	{
		$field = implode(',',array_keys($data));			//SQLステートメントに定義されたフィールドの一部
		$i = 0;
		$value="";
		foreach($data as $key => $val)						//SQL文の値の組み合わせ
		{
			$value .= "'" . $val . "'";
			if($i < count($data) - 1)						//配列の最後の値かどうかをチェック
				$value .= ",";
			$i++;
		}
		$sql = "INSERT INTO " . $name . "(" . $field . ") VALUES(" . $value . ")";
		return $this->insert($sql);
	}
   /**
	* 機能：指定したテーブルを更新するために指定されたIDを記録
	* パラメータ：$name テーブル名, $id PKの値, $data 配列（フォーマット：$data['フィールド名']=値）
	* 戻り値：TRUE OR FALSE
	*/
	public function updateData($name,$id,$data){
		$col = array();
		foreach ($data as $key => $value)
		{
			$col[] = $key . "='" . $value . "'";
		}
		$sql = "UPDATE " . $name . " SET " . implode(',',$col) . " WHERE ID = $id";
		return $this->update($sql);
	}

   /**
	* 機能：指定したテーブルを更新するために指定されたIDを記録
	* パラメータ：$name テーブル名, $id PKの値, $data 配列（フォーマット：$data['フィールド名']=値）
	* 戻り値：TRUE OR FALSE
	* 追加日：2012/02/14 koike
	*/
	public function updateDatakai($name,$id1,$id2,$data){
		$col = array();
		foreach ($data as $key => $value)
		{
			$col[] = $key . "='" . $value . "'";
		}
		$sql = "UPDATE " . $name . " SET " . implode(',',$col) . " WHERE " .$id1. "=". $id2;
		return $this->update($sql);
	}

	/**
	 * 機能：レコードを削除するテーブルのIDを指定
	 * パラメータ：$id PKの値, $name テーブル名
	 * 戻り値：TRUE OR FALSE
	 */
	public function delData($name,$id)
	{
		$sql = "DELETE FROM " . $name . " WHERE ID = $id";
		return $this->delete($sql);
	}

	/**
	 * 機能：レコードを削除するテーブルのIDを指定
	 * パラメータ：$id PKの値, $name テーブル名
	 * 戻り値：TRUE OR FALSE
	 * 追加日：2012/02/14 koike
	 */
	public function delDatakai($name,$id1,$id2)
	{
		$sql = "DELETE FROM " . $name . " WHERE " .$id1." = ".$id2;
		return $this->delete($sql);
	}
}
?>