<?php
function fit($file, $path, $w, $h, $mode='fit') {
	//画像ファイル名
	if (substr($path, -1)!='/')  $path.='/';
	$src_file = $path.$file;
	
	//ファイル存在チェック
	if (!file_exists($src_file)) {
		return false;
	}
	
	//ファイルタイプチェック
	list($width, $height, $type,) = getimagesize($src_file);
	if ($type!=1 && $type!=2 && $type!=3) {
		return false;
	}
	
	//縦横比
	$cmd='';
	$new_rate=$h/$w;
	$old_rate=$height/$width;

	//コマンド
	switch ($mode) {
		case 'fit':
			//縦横比固定でトリミング

			//サイズ小
			if ($w>$width || $h>$height) {
				//ピクセル計算
				$new_h=round($width*$new_rate);
				$new_w=round($height/$new_rate);
				//幅からみた縦の新ピクセル数が不足
				if ($new_h<$height) {
					$cw=$width;
					$ch=$new_h;
				} else {
					$cw=$new_w;
					$ch=$height;
				}
				//トリミング計算
				$cx=round(($width-$cw)/2);
				$cy=round(($height-$ch)/2);
				$cmd="-crop {$cw}x{$ch}+{$cx}+{$cy}";
			} else {
				if ($new_rate<$old_rate) {
					//新画像の方が幅広画像
					$tw=$w;
					$th=round($w*$old_rate);
				} else {
					$tw=round($h/$old_rate);
					$th=$h;
				}
				//トリミング計算
				$cx=round(($tw-$w)/2);
				$cy=round(($th-$h)/2);				
				$cmd="-thumbnail {$tw}x{$th} -crop {$w}x{$h}+{$cx}+{$cy} +repage";
			}
			break;
		case 'wfit':
			//横幅に合わせる
			if ($w>$width) {
				//画像サイズ小
				$cmd='';
			} else {
				//画像サイズ大
				$cmd="-resize {$w}x";
			}
			break;
		case 'hfit':
			//高さに合わせる
			if ($h>$height) {
				//画像サイズ小
				$cmd='';
			} else {
				//画像サイズ大
				$cmd="-resize x{$h}";
			}
			break;
	}
	$new=date('YmdHis')."_".rand(100,999).'.jpg';
	$new_file=$path.$new;
	if (!empty($cmd)) {
		$cmd="/usr/bin/convert ".$cmd." '{$src_file}' '{$new_file}'";
		exec($cmd, $output, $result);
		if (!$result) {
			return $new;
		} else {
			return false;
		}
	} else {
		copy($src_file, $new_file);
		return $new;
	}
}
?>