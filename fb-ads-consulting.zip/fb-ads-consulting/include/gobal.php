<?php
//ini_set("session.bug_compat_42", 0);
//ini_set("session.bug_compat_warn", 0);
session_start();
//@header('Content-Type:text/html;charset=utf-8');
require("config.inc.php");
?>