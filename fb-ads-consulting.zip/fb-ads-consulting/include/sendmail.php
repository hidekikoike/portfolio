<?php
//メール送信
function sendtomail($to,$from,$title,$naiyo) {
	if ($to!='') {
		if (strpos($to,'ezweb.ne.jp') === false) {
			//メールの送信
			mb_language("Japanese");
			mb_internal_encoding("utf-8");
			$mailfrom="From:{$from}";
		} else {
			//メールの送信
			mb_language("Japanese");
			mb_internal_encoding("ISO-2022-JP");
			$title = mb_convert_encoding($title, "ISO-2022-JP","UTF-8,SJIS,EUC-JP");
			$naiyo = mb_convert_encoding($naiyo, "ISO-2022-JP","UTF-8,SJIS,EUC-JP");
			$mailfrom="From:{$from}";
		}
		mb_send_mail($to,$title,$naiyo,$mailfrom);
		mb_internal_encoding("UTF-8");
		return true;
	} else {
		return false;
	}
}
?>
