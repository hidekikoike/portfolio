<?php
error_reporting(1);
require("../include/gobal.php");
require("../include/class.db.php");
$db = new db("mysql:host=".SYS_DBHOST.";dbname=".SYS_DBNAME, SYS_DBUSER, SYS_DBPW);

$csv=$_POST['csv'];

$array = explode("\n", $csv);
$a = false;

$sql = "select email_name from user";
$user = $db->run($sql);

$email_name = array();

foreach ($user as $u){
	$email_name[] = $u['email_name'];
}

foreach ($array as $line) {
	$line=str_replace('"','',$line);
	$colum = explode(",", $line);
	if($colum[0]!='メールアドレス'&&!in_array($colum[0],$email_name)){
	//$sql = "insert into user('email_name','date') values('$colum[0]','$colum[1]')";
	$data = array();
	$data['email_name'] = $colum[0];
	$data['date'] = $colum[1];
	$db->insert('user',$data);	
	}
}

  //$data = array();
  //$data['email_name'] = 'a';
  //$data['date'] = '2016-10-27';
  //$db->insert('user',$data);

?>