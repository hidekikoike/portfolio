<?php
require("include/gobal.php");
require("include/db.inc.php");
require("include/function.php");
require("include/sendmail.php");
//session_start();
?>

<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<meta name="robots" content="noindex,nofollow">
<title>Rutubo Consulting | FB広告4週間集中コンサルティング</title>
<meta name="description" content="Rutubo Consulting | FB広告4週間集中コンサルティング" />
<meta name="keywords" content="FB広告,ネット集客" />
<meta name="viewport" content="width=device-width,initial-scale=1.0" />
<!--<link rel="icon" href="favicon.ico" type="image/.icon" />-->
<!--<link rel="Shortcut Icon" href="favicon.ico" type="image/.icon" />-->
<link rel="stylesheet" type="text/css" href="css/top.css">
<script type="text/javascript" src="js/footerFixed.js"></script>
<script type="text/javascript" src="js/ga.js"></script>
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
<link rel="icon" href="images/favicon.ico" type="image/x-icon">
<style type="text/css">
#formWrap {
	max-width: 700px;
	margin:0 auto;
	margin-top:30px;
	font-size: 117%;
}
table.formTable{
	width:100%;
	margin:0 auto;
	border-collapse:collapse;
}
table.formTable td,table.formTable th{
	border:1px solid #ccc;
	padding:10px;
}
table.formTable th{
	width:30%;
	font-weight:normal;
	background:#efefef;
	text-align:left;
}
p.error_messe{
	margin:5px 0;
	color:red;
}
body{
	background: #fff;
	background-image: url(../images/header_line.png);
	background-repeat: repeat-x;
}
</style>
<title>確認画面</title>
</head>

<body id="subpage">

<?php include_once("analyticstracking.php") ?>

<header id="pagetop">

	<header id="header" role="banner">
	  <div class="header">
	    <p class="header_title"><img src="images/header_title.png" alt=""></p>
	    <p class="header_company"><img src="images/header_company.png" alt=""></p>
	  </div>
	</header>

	<!-- COUNTDOWN -->
	<!--
	<div class="timer_box">
		<div class="timer">  
			<div class="timer_1" id="sampleA"></div>  
				<div class="countdown"></div>
		</div>
	</div>-->

	</div>
</div>

<?php
$err1 = "";
$err2 = "";
$err3 = "";
$err4 = "";
$err5 = "";
$err6 = "";
$err7 = "";

if(empty($_POST["contact_type1"])){
	$err1="※ご決済方法のご記入は必須です。<br />\n";
}
if(empty($_POST["company"])) {
	$err2.="※御社名のご記入は必須です。<br />\n";
}
if(empty($_POST["company"])) {
	$err2.="※御社名のご記入は必須です。<br />\n";
}
if(empty($_POST["name"])) {
	$err3.="※氏名のご記入は必須です。<br />\n";
}
if(empty($_POST["email"])){
	$err4="※メールアドレスのご記入は必須です。<br />\n";
}
if (!preg_match("/^([a-zA-Z0-9])+([a-zA-Z0-9\._-])*@([a-zA-Z0-9_-])+([a-zA-Z0-9\._-]+)+$/", $_POST["email"])) {
	$err4.="※メールアドレスの書式が正しくありません。<br />\n";
}
if(empty($_POST["tel"])){
	$err5="※電話番号のご記入は必須です。<br />\n";
}
//if (!preg_match("/^0\d{1,4}-\d{1,4}-\d{4}$/", $_POST["tel"])) {
//	$err5.="※電話番号の書式が正しくありません。<br />\n";
//}
if(empty($_POST["comment"])){
	$err6.="※備考のご記入は必須です。<br />\n";
}
if(empty($_POST["legal"])){
	$err7.="※規約の同意は必須です。<br />\n";
}

if($err1 or $err2 or $err3 or $err4 or $err5 or $err6 or $err7){
	$err=$err1.$err2.$err3.$err4.$err5.$err6.$err7;
}


?>
<?php
if(!empty($err) && empty($mode)){

?>
<div align="center">
<div class="mg-t3 TXT-M">
<h3>入力にエラーがあります。下記をご確認の上「戻る」ボタンにて修正をお願い致します。</h3>
<p class="error_messe"><?= $err ?></p>
<a href="javascript:history.back()"><img src="images/contact_btn_back.png"></a>
</div>
</div>
<?php
//}else if($_POST["mode"]=="") {
}else{
?>
<div id="formWrap">
<h3>確認画面</h3>
<p align="center">以下の内容で間違いがなければ、「送信する」ボタンを押してください。</p>
<form action="thanks.php" method="POST">
<table class="formTable">
<tr><th>ご決済方法</th><td><?= $_POST['contact_type1']?><input type="hidden" name="contact_type1" value="<?= $_POST['contact_type1']?>" /></td></tr>
<tr><th>御社名</th><td><?= $_POST['company']?><input type="hidden" name="company" value="<?= $_POST['company']?>" /></td></tr>
<tr><th>氏名</th><td><?= $_POST['name']?><input type="hidden" name="name" value="<?= $_POST['name']?>" /></td></tr>
<tr><th>メールアドレス</th><td><?= $_POST['email']?><input type="hidden" name="email" value="<?= $_POST['email']?>" /></td></tr>
<tr><th>電話番号</th><td><?= $_POST['tel']?><input type="hidden" name="tel" value="<?= $_POST['tel']?>" /></td></tr>
<tr><th>郵便番号</th><td><?= $_POST['zip']?><input type="hidden" name="zip" value="<?= $_POST['zip']?>" /></td></tr>
<tr><th>住所</th><td><?= $_POST['address']?><input type="hidden" name="address" value="<?= $_POST['address']?>" /></td></tr>
<tr><th>ホームページURL</th><td><?= $_POST['url']?><input type="hidden" name="url" value="<?= $_POST['url']?>" /></td></tr>
<tr><th>Facebook広告徹底ガイド動画講座購入の有無</th><td><?= $_POST['contact_type2']?><input type="hidden" name="contact_type2" value="<?= $_POST['contact_type2']?>" /></td></tr>
<tr><th>備考</th><td><?= $_POST['comment']?><input type="hidden" name="comment" value="<?= $_POST['comment']?>" /></td></tr>
<tr><th>規約</th><td><?= $_POST['legal']?><input type="hidden" name="legal" value="<?= $_POST['legal']?>" /></td></tr>
</table>

<!--<input type="hidden" name="mail_set" value="confirm_submit">-->
<input type="hidden" name="mode" value="mail_send">
<input type="hidden" name="emailCheck" value="<?= $_POST['emailCheck']?>">

<div class="clear"></div>

<div class="center mg-t2 mg-b2">
<a href="javascript:history.back()"><img class="btn1" src="images/contact_btn_back.png"></a>
<input class="btn2" name="con_send" src="images/contact_btn_send.png" type="image" alt="" />
</div>

</form>
</div><!-- /formWrap -->

<?php
}
?>

<footer>

<div id="footer">
	<div id="fbottom">
		<div class="fwrap">
			<p id="fcopy"><strong>Rutubo Consulting</strong></p>
			<p id="copyright"><small>&copy;2011~2016 Rutubo.LLC All Rights Reserved.</small></p>
		</div>
	</div>
</div>

</footer>

</body>
</html>