$(function() {
$(".air-conditioning").mouseover(function() {
    $(this).children('ul').show();
}).mouseout(function(){
    $(this).children('ul').hide();
});
});