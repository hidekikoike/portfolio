// JavaScript Document

/**
 * Limited View
 * Check javascript
 *
	@mngID			管理ID
	@expiredPage	期限切れ表示ページURL
	@validHours		有効表示時間
	@cookieName		Cookie名
 */

	var	mngID;
	var	expiredPage;
	var	validHours;
	var	expiredCookieName;
	var	firstTimeCookieName;

	/**
	 * 有効期限を取得
	 */
	function getTimeLimit( id, page, hours ) {
		mngID = id;
		expiredPage = page;
		validHours = hours;
		expiredCookieName = 'EXPIRED_' + mngID;
		firstTimeCookieName = 'FIRSTTIME_' + mngID;

		var timeLimit = isLimited();

		if ( !timeLimit )	{
			// 期限切れページを表示
			displayExpiredPage();
		}

		return timeLimit;
	}

	/**
	 * 初回アクセス日を取得
	 */
	function getFirstTimeAccess() {

		var	firstTime =new Date( $.cookie( firstTimeCookieName ) );

		firstTime = firstTime.getFullYear() + '/' + ( firstTime.getMonth() + 1 ) + '/' + firstTime.getDate() + '/' +  addZero( firstTime.getHours() ) + ':' +  addZero( firstTime.getMinutes() ) + ':' +  addZero( firstTime.getSeconds() );

		return firstTime;

	}

	/**
	 * 有効期限チェック
	 */
	function isLimited()	{

		// Cookie読み出し
		var	timeLimit = ( $.cookie( expiredCookieName ) );

		now =  ( new Date() ).getTime();

		if ( !timeLimit )	{
			// 有効期限を取得
			var	limitDate = new Date( ( validHours * 60 * 60 * 1000 ) + now );
			timeLimit = limitDate.getTime();

			// Cookieに書き込み
			// 有効期限
			$.cookie( expiredCookieName, timeLimit, { expires: 30 } );
			// 初回アクセス日
			$.cookie( firstTimeCookieName, new Date(), { expires: 30 } );

		}

		if ( timeLimit <= now )	{
			return false;
		}

		return timeLimit;
	}

	/**
	 * 期限切れページを表示
	 */
	function displayExpiredPage()	{
		window.location.href = expiredPage;
	}

	/**
	 * ゼロを付与
	 */
	function addZero( num )	{
		num = '00' + num;
		str = num.substring( num.length - 2, num.length );

		return str ;
	}
