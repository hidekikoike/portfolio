$(function() {
	//2�ȉ��̉摜���̃��[�_������ݒ�
	$('.modal-group').each(function(){
		var modalList=$(this).children('.modal-list');
		var len=modalList.length;
		if (len==1) {
			modalList.css('width', '100%');
		} else if (len==2) {
			modalList.css('width', '49.5%');
		}
	});
	//���[�_���I�[�v��
	$('a[id^="open"]').click(function(){
		var num=parseInt($(this).attr('id').substr(4));
		$('#modal'+num).plainModal('open', {
			duration: 500,
			overlay: {color: '#000', opacity: 0.75},
		});
		$('#modal'+num).on('plainmodalopen', function(event) {
			//��ʂ̍����𒴉�
			h=$(window).height();
			mW=$('#modal'+num).innerWidth();
			mH=$('#modal'+num).innerHeight();
			if (h < mH) {
				var nW=parseInt(mW*(h-100)/mH);
				var nH=parseInt(mH*nW/mW);
				$('#modal'+num).animate({
					width:  nW + 'px',
					marginLeft: (parseInt($('#modal'+num).css('marginLeft')) + (mW-nW)/2) + 'px',
					marginTop: (parseInt($('#modal'+num).css('marginTop')) + (mH-nH)/2.5) + 'px'
				}, 300);
			}
		});
	});
	//�N���[�Y�{�^��
	$('.modal-close a').click(function(){
		$(this).parent('p').parent('div').plainModal('close');
	});
	$('.modal-close a').focus(function(){
		$(this).blur();
	});
});