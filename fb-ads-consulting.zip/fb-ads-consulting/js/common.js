$(function() {	
	/* �X�}�t�H�psidr���j���[ */
	var wid = $(window).width();
	if ( wid <= 480 ) {
		$('#gmenu').attr('id', 'sidr');
		$('#sbutton').attr('href', '#sidr');
		$('#sbutton').sidr({
      		name: 'sidr',
      		side: 'right'
    		});
	}
	$('.close').click(function() {
		  $.sidr('close', 'sidr');
	});
});
