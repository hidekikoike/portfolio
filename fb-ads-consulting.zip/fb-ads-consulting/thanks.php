<?php
require("include/gobal.php");
require("include/db.inc.php");
require("include/function.php");
require("include/sendmail.php");
//session_start();
?>

<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<meta name="robots" content="noindex,nofollow">
<title>Rutubo Consulting | FB広告4週間集中コンサルティング</title>
<meta name="description" content="Rutubo Consulting | FB広告4週間集中コンサルティング" />
<meta name="keywords" content="FB広告,ネット集客" />
<meta name="viewport" content="width=device-width,initial-scale=1.0" />
<!--<base href="http://www.ist-concept.co.jp/">-->
<!--<link rel="icon" href="favicon.ico" type="image/.icon" />-->
<!--<link rel="Shortcut Icon" href="favicon.ico" type="image/.icon" />-->
<link rel="stylesheet" type="text/css" href="css/top.css">
<link rel="stylesheet" type="text/css" href="css/form.css">
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
<script type="text/javascript" src="js/footerFixed.js"></script>
<script type="text/javascript" src="js/ga.js"></script>
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
<link rel="icon" href="images/favicon.ico" type="image/x-icon">

<style type="text/css">
body {
	background: #fff;
	background-image: url(../images/header_line.png);
	background-repeat: repeat-x;
}
</style>

</head>

<body id="subpage">

<?php include_once("analyticstracking.php") ?>

<header id="pagetop">

	<header id="header" role="banner">
	  <div class="header">
	    <p class="header_title"><img src="images/header_title.png" alt=""></p>
	    <p class="header_company"><img src="images/header_company.png" alt=""></p>
	  </div>
	</header>

	<div id="mainv">
		<p id="mainfront"><img src="images/main_front.png" /></p>
	</div>

	<div align="center">
		<div class="MG-T30 mg-b3 TXT-M">
			Facebook広告4週間集中コンサルティングにお申し込み頂き、誠に有難うございました。<br /><br />
			コンサルティング会費のお振込み先はメールにてお送りしました。<br />
			本日から3日以内にご入金ください。<br /><br />
			なお、メールの受信が確認できない場合は、<br />お手数ですがinfo@rutubo-consulting.jpまでご連絡をお願い致します。<br /><br />
			<a href="http://www.rutubo-consulting.jp/">トップページへ戻る⇒</a>
		</div>
	</div>

<?php
if($_POST["mode"]=="mail_send") {
	
//お問い合わせ内容送信（お客様宛メール）ここから
//メール送信先
$to=$_POST["email"];
//メールタイトル
$subj="【Facebook広告4週間集中コンサルティング受付】お申し込み完了のご連絡";
//お問い合わせ名
//$from .= "RutuboConsulting\n";
$from="RutuboConsulting\n";
//お問い合わせ本文
$body = "";
$body .= $_POST["name"]."様"."\n";
$body .= "\n";
$body .= "\n";
$body .= "いつも大変お世話になっております。\n";
$body .= "\n";
$body .= "\n";
$body .= "合同会社Rutubo\n";
$body .= "カスタマーサポートチームでございます。\n";
$body .= "\n";
$body .= "この度は、弊社の\n";
$body .= "【Facebook広告4週間集中コンサルティング】に\n";
$body .= "お申し込みを頂き、誠にありがとうございました。\n";
$body .= "\n";
$body .= "ぜひ、".$_POST["name"]."様"."のお力になれるよう、\n";
$body .= "精一杯、サポートさせて頂きます。\n";
$body .= "\n";
$body .= "以下より、ご入金に関するご案内をさせて頂きます。\n";
$body .= "ご確認の上、ご対応頂けますようお願い申し上げます。\n";
$body .= "\n";
$body .= "\n";
$body .= "▼お申込み内容をご確認いただき、以下の手順にて\n";
$body .= "コンサルティング費用のお支払い手続きをお願い致します。\n";
$body .= "\n";
$body .= "※本コンサルティングは、事前のご入金手続きが必要となります。\n";
$body .= "\n";
$body .= "\n";
$body .= "【銀行振込でのお支払いのご案内】\n";
$body .= "\n";
$body .= "本サービスでは、コンサルティング費用を\n";
$body .= "銀行振込にて事前にご入金頂くよう、お願いしております。\n";
$body .= "\n";
$body .= "つきましては、お手数をおかけしますが、\n";
$body .= "下記の通り、当社指定口座まで事前にお振込願います。\n";
$body .= "\n";
$body .= "\n";
$body .= "１）ご入金の際は、お申込者様と同じご名義にて、お振込をお願い致します。\n";
$body .= "法人名でのお振込や、別名義でのお振込の場合は、事前にご一報を\n";
$body .= "お願い致します。　⇒　info@rutubo-consulting.jp\n";
$body .= "\n";
$body .= "２）お申込日から3日以内に、下記振込先にご入金ください。\n";
$body .= "\n";
$body .= "■Facebook広告徹底ガイド動画講座を購入されていない方：　199,800円（税込）\n";
$body .= "\n";
$body .= "■Facebook広告徹底ガイド動画講座を購入された方：　159,800円（税込）\n";
$body .= "\n";
$body .= "\n";
$body .= "＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝\n";
$body .= "（お振込み先）\n";
$body .= "\n";
$body .= "銀行名： 第四銀行\n";
$body .= "\n";
$body .= "支店名： 本店（200）\n";
$body .= "\n";
$body .= "普通預金　2580778\n";
$body .= "\n";
$body .= "口座名義：合同会社Rutubo代表社員小池英樹\n";
$body .= "\n";
$body .= "＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝\n";
$body .= "※誠に恐れ入りますが、振込手数料はお客様ご負担にてお願い致します。\n";
$body .= "\n";
$body .= "\n";
$body .= "３）弊社でご入金を確認後、入金確認・受付完了のメールをお送りいたします。\n";
$body .= "\n";
$body .= "\n";
$body .= "ご案内は以上でございます。\n";
$body .= "それでは、".$_POST["name"]."様"."と直接お話できる時を\n";
$body .= "楽しみにお待ち申し上げております。\n";
$body .= "\n";
$body .= "\n";
$body .= "今後のサービスの流れにつきましては、\n";
$body .= "ご入金確認のメールと合わせて\n";
$body .= "ご案内させて頂きます。\n";
$body .= "\n";
$body .= "\n";
$body .= "まずはご入金の手続きを\n";
$body .= "完了頂けますよう、お願い致します。\n";
$body .= "\n";
$body .= "\n";
$body .= "今後とも、何卒よろしくお願い申し上げます。\n";
$body .= "\n";
$body .= "----------------------------------------------------------\n";
$body .= "合同会社Rutubo\n";
$body .= "TEL:03-5283-6242\n";
$body .= "e-mail:info@rutubo-consulting.jp\n";
$body .= "----------------------------------------------------------\n";

sendtomail("$to",$from,$subj,$body);
//お問い合わせ内容送信（お客様宛メール）ここまで

//お問い合わせ内容送信（小池宛メール）ここから
//メールタイトル
$subj="【Facebook広告4週間集中コンサルティング】にお申し込みがありました。";
//お問い合わせ名
$from=$_POST["email"];
//お問い合わせ本文
$body = "下記の内容でお申し込みを承りました。\n";
$body .= "----------------------------------------------------------\n";
$body .= "ご決済方法".$_POST["contact_type1"]."\n";
$body .= "御社名：".$_POST["company"]."\n";
$body .= "氏名：".$_POST["name"]."\n";
$body .= "メールアドレス：".$_POST["email"]."\n";
$body .= "電話番号：".$_POST["tel"]."\n";
$body .= "郵便番号：".$_POST["zip"]."\n";
$body .= "住所：".$_POST["address"]."\n";
$body .= "ホームページURL：".$_POST["url"]."\n";
$body .= "Facebook広告徹底ガイド動画講座購入の有無：".$_POST["contact_type2"]."\n";
$body .= "備考：".$_POST["comment"]."\n";
$body .= "規約：".$_POST["legal"]."\n";
$body .= "----------------------------------------------------------\n";
sendtomail("hdkoike@rutubo-web.com",$from,$subj,$body);
sendtomail("hdkoike@web-rutubo.com",$from,$subj,$body);
//お問い合わせ内容送信（お客様宛メール）ここまで

?>

<?php
}
?>

<footer>

<div id="footer">
	<div id="fbottom">
		<div class="fwrap">
			<p id="fcopy"><strong>Rutubo Consulting</strong></p>
			<p id="copyright"><small>&copy;2011~2016 Rutubo.LLC All Rights Reserved.</small></p>
		</div>
	</div>
</div>

</footer>

</body>
</html>